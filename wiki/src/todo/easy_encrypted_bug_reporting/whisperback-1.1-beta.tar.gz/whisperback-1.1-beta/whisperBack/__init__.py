import gettext
from whisperback import WhisperBackUI

# FIXME: hardcoded path
gettext.install('whisperback', localedir='/usr/share/locale', unicode=True)
