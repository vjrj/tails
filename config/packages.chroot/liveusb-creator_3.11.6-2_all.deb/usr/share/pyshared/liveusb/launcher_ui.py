# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'data/liveusb-creator-launcher.ui'
#
# Created: Fri Apr 13 14:15:47 2012
#      by: PyQt4 UI code generator 4.9.1
#
# WARNING! All changes made in this file will be lost!


import sys
if sys.platform == "win32":
    from liveusb import utf8_gettext as _
else:
    from liveusb import _
from liveusb import branding

def translate_and_brand(string):
    return _(string) % branding

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(530, 363)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Fixed, QtGui.QSizePolicy.MinimumExpanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Dialog.sizePolicy().hasHeightForWidth())
        Dialog.setSizePolicy(sizePolicy)
        Dialog.setMinimumSize(QtCore.QSize(512, 300))
        Dialog.setMaximumSize(QtCore.QSize(16777215, 16777215))
        Dialog.setBaseSize(QtCore.QSize(512, 300))
        self.widget = QtGui.QWidget(Dialog)
        self.widget.setGeometry(QtCore.QRect(2, 9, 520, 349))
        self.widget.setObjectName(_fromUtf8("widget"))
        self.verticalLayout = QtGui.QVBoxLayout(self.widget)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setContentsMargins(6, -1, 6, -1)
        self.gridLayout.setVerticalSpacing(6)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.cloneInstallButton = QtGui.QPushButton(self.widget)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.MinimumExpanding, QtGui.QSizePolicy.MinimumExpanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.cloneInstallButton.sizePolicy().hasHeightForWidth())
        self.cloneInstallButton.setSizePolicy(sizePolicy)
        self.cloneInstallButton.setMinimumSize(QtCore.QSize(200, 96))
        self.cloneInstallButton.setMaximumSize(QtCore.QSize(16777215, 16777215))
        self.cloneInstallButton.setBaseSize(QtCore.QSize(200, 96))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.cloneInstallButton.setFont(font)
        self.cloneInstallButton.setIconSize(QtCore.QSize(64, 64))
        self.cloneInstallButton.setObjectName(_fromUtf8("cloneInstallButton"))
        self.gridLayout.addWidget(self.cloneInstallButton, 0, 0, 1, 1)
        self.cloneInstallLabel = QtGui.QLabel(self.widget)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.MinimumExpanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.cloneInstallLabel.sizePolicy().hasHeightForWidth())
        self.cloneInstallLabel.setSizePolicy(sizePolicy)
        self.cloneInstallLabel.setMinimumSize(QtCore.QSize(300, 0))
        self.cloneInstallLabel.setMaximumSize(QtCore.QSize(16777215, 16777215))
        self.cloneInstallLabel.setBaseSize(QtCore.QSize(300, 96))
        self.cloneInstallLabel.setWordWrap(True)
        self.cloneInstallLabel.setMargin(6)
        self.cloneInstallLabel.setObjectName(_fromUtf8("cloneInstallLabel"))
        self.gridLayout.addWidget(self.cloneInstallLabel, 0, 1, 1, 1)
        self.cloneUpgradeButton = QtGui.QPushButton(self.widget)
        self.cloneUpgradeButton.setEnabled(True)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.MinimumExpanding, QtGui.QSizePolicy.MinimumExpanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.cloneUpgradeButton.sizePolicy().hasHeightForWidth())
        self.cloneUpgradeButton.setSizePolicy(sizePolicy)
        self.cloneUpgradeButton.setMinimumSize(QtCore.QSize(200, 96))
        self.cloneUpgradeButton.setBaseSize(QtCore.QSize(0, 96))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.cloneUpgradeButton.setFont(font)
        self.cloneUpgradeButton.setIconSize(QtCore.QSize(128, 128))
        self.cloneUpgradeButton.setObjectName(_fromUtf8("cloneUpgradeButton"))
        self.gridLayout.addWidget(self.cloneUpgradeButton, 1, 0, 1, 1)
        self.cloneUpgradeLabel = QtGui.QLabel(self.widget)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.MinimumExpanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.cloneUpgradeLabel.sizePolicy().hasHeightForWidth())
        self.cloneUpgradeLabel.setSizePolicy(sizePolicy)
        self.cloneUpgradeLabel.setMinimumSize(QtCore.QSize(300, 0))
        self.cloneUpgradeLabel.setMaximumSize(QtCore.QSize(16777215, 16777215))
        self.cloneUpgradeLabel.setBaseSize(QtCore.QSize(300, 96))
        self.cloneUpgradeLabel.setWordWrap(True)
        self.cloneUpgradeLabel.setMargin(6)
        self.cloneUpgradeLabel.setObjectName(_fromUtf8("cloneUpgradeLabel"))
        self.gridLayout.addWidget(self.cloneUpgradeLabel, 1, 1, 1, 1)
        self.upgradeFromIsoButton = QtGui.QPushButton(self.widget)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.MinimumExpanding, QtGui.QSizePolicy.MinimumExpanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.upgradeFromIsoButton.sizePolicy().hasHeightForWidth())
        self.upgradeFromIsoButton.setSizePolicy(sizePolicy)
        self.upgradeFromIsoButton.setMinimumSize(QtCore.QSize(200, 96))
        self.upgradeFromIsoButton.setBaseSize(QtCore.QSize(0, 96))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.upgradeFromIsoButton.setFont(font)
        self.upgradeFromIsoButton.setIconSize(QtCore.QSize(128, 128))
        self.upgradeFromIsoButton.setObjectName(_fromUtf8("upgradeFromIsoButton"))
        self.gridLayout.addWidget(self.upgradeFromIsoButton, 2, 0, 1, 1)
        self.upgradeFromIsoLabel = QtGui.QLabel(self.widget)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.MinimumExpanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.upgradeFromIsoLabel.sizePolicy().hasHeightForWidth())
        self.upgradeFromIsoLabel.setSizePolicy(sizePolicy)
        self.upgradeFromIsoLabel.setMinimumSize(QtCore.QSize(300, 0))
        self.upgradeFromIsoLabel.setMaximumSize(QtCore.QSize(16777215, 16777215))
        self.upgradeFromIsoLabel.setBaseSize(QtCore.QSize(300, 96))
        self.upgradeFromIsoLabel.setWordWrap(True)
        self.upgradeFromIsoLabel.setMargin(6)
        self.upgradeFromIsoLabel.setObjectName(_fromUtf8("upgradeFromIsoLabel"))
        self.gridLayout.addWidget(self.upgradeFromIsoLabel, 2, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        self.helpLabel = QtGui.QLabel(self.widget)
        self.helpLabel.setMargin(6)
        self.helpLabel.setObjectName(_fromUtf8("helpLabel"))
        self.verticalLayout.addWidget(self.helpLabel)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(translate_and_brand('%(distribution)s LiveUSB Creator'))
        self.cloneInstallButton.setText(translate_and_brand('Clone\n&&\nInstall'))
        self.cloneInstallLabel.setText(translate_and_brand('<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN" "http://www.w3.org/TR/REC-html40/strict.dtd">\n<html><head><meta name="qrichtext" content="1" /><style type="text/css">\np, li { white-space: pre-wrap; }\n</style></head><body style=" font-family:\'Sans Serif\'; font-size:9pt; font-weight:400; font-style:normal;">\n<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:10pt;">Copy the running Tails onto a USB stick. All data on the target drive will be lost.</span></p></body></html>'))
        self.cloneUpgradeButton.setText(translate_and_brand('Clone\n&&\nUpgrade'))
        self.cloneUpgradeLabel.setText(translate_and_brand('<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN" "http://www.w3.org/TR/REC-html40/strict.dtd">\n<html><head><meta name="qrichtext" content="1" /><style type="text/css">\np, li { white-space: pre-wrap; }\n</style></head><body style=" font-family:\'Sans Serif\'; font-size:9pt; font-weight:400; font-style:normal;">\n<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:10pt;">Copy the running Tails onto an already installed Tails USB stick. Other partitions found on the stick are preserved.</span></p></body></html>'))
        self.upgradeFromIsoButton.setText(translate_and_brand('Upgrade from ISO'))
        self.upgradeFromIsoLabel.setText(translate_and_brand('<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN" "http://www.w3.org/TR/REC-html40/strict.dtd">\n<html><head><meta name="qrichtext" content="1" /><style type="text/css">\np, li { white-space: pre-wrap; }\n</style></head><body style=" font-family:\'Sans Serif\'; font-size:9pt; font-weight:400; font-style:normal;">\n<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:10pt;">Upgrade an already installed Tails USB stick from a new ISO image.</span></p></body></html>'))
        self.helpLabel.setText(translate_and_brand('<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN" "http://www.w3.org/TR/REC-html40/strict.dtd">\n<html><head><meta name="qrichtext" content="1" /><style type="text/css">\np, li { white-space: pre-wrap; }\n</style></head><body style=" font-family:\'Sans Serif\'; font-size:9pt; font-weight:400; font-style:normal;">\n<p align="center" style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:10pt;">Need help? Read the </span><a href="file:///usr/share/doc/tails/website/doc/first_steps/usb_installer.en.html"><span style=" text-decoration: underline; color:#0000ff;">documentation</span></a><span style=" font-size:10pt;">.</span></p></body></html>'))

import resources_rc
