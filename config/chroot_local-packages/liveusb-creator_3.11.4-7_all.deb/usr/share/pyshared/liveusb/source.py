# -*- coding: utf-8 -*-

import os
import shutil
import sys
import subprocess
from stat import ST_SIZE
from liveusb import _
from liveusb.releases import releases
from liveusb.utils import (_to_unicode, _dir_size, iso_is_live_system,
                           unicode_to_utf8, _set_liberal_perms_recursive,
                           underlying_physical_device)

class SourceError(Exception):
    """ A generic error message that is thrown by the Source classes """

class Source(object):
    def clone(self, destination):
        raise NotImplementedError
    def supports_verify_md5(self):
        return False
    def supports_verify_sha1(self):
        return False

class LocalIsoSource(Source):
    def supports_verify_md5(self):
        return True
    def supports_verify_sha1(self):
        return True
    def __init__(self, path):
        self.path = os.path.abspath(_to_unicode(path))
        self.size = os.stat(self.path)[ST_SIZE]
        if not iso_is_live_system(self.path):
            raise SourceError(_("Unable to find LiveOS on ISO"))
        self.dev  = None
        # This can fail for devices not supported by UDisks such as aufs mounts
        try:
            self.dev = underlying_physical_device(self.path)
        except Exception, e:
            print >> sys.stderr, _("Could not guess underlying block device: %s"
                                   % e.args[0])
            pass

    def clone(self, destination):
        cmd = ['7z', 'x', unicode_to_utf8(self.path),
               '-x![BOOT]', '-y', '-o%s' % (destination)]
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE)
        out, err = proc.communicate()
        if proc.returncode:
            raise SourceError(_("There was a problem executing `%s`."
                                "%s\n%s" % (cmd, out, err)))
        _set_liberal_perms_recursive(destination)

    def get_release(self):
        """ If the ISO is for a known release, return it. """
        isoname = os.path.basename(self.path)
        for release in releases:
            if os.path.basename(release['url']) == isoname:
                return release

    def verify_md5(self):
        """ Verify the ISO md5sum.
        At the moment this is Linux specific since checkisomd5 does not work
        on Windows.
        """
        if sys.platform == 'win32':
            return True
        cmd = ['checkisomd5', unicode_to_utf8(self.path)]
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE)
        out, err = proc.communicate()
        if proc.returncode:
            raise SourceError(_("ISO MD5 checksum verification failed:"
                                "%s\n%s" % (out, err)))
        return True

class RunningLiveSystemSource(Source):
    def __init__(self, path):
        if not os.path.exists(path):
            raise SourceError(_("'%s' does not exist") % path)
        if not os.path.isdir(path):
            raise SourceError(_("'%s' is not a directory") % path)
        self.path = path
        self.size = _dir_size(self.path)
        self.dev  = underlying_physical_device(self.path)
    def clone(self, destination):
        for f in os.listdir(self.path):
            src = os.path.join(self.path, f)
            dst = os.path.join(destination, f)
            if os.path.isfile(src):
                shutil.copy(src, dst)
            elif os.path.islink(src):
                linkto = os.readlink(src)
                os.symlink(linkto, dst)
            elif os.path.isdir(src):
                shutil.copytree(src, dst)
        _set_liberal_perms_recursive(destination)
