# -*- coding: utf-8 -*-
#
# Copyright © 2012, Tails developers <tails@boum.org>

"""
A unified launcher for the most common LiveUSBCreator usecases
"""

from liveusb import LiveUSBLauncherInterface, _
from PyQt4 import QtCore, QtGui
import os

class LiveUSBLauncher(QtGui.QApplication):
    """ Main application class """
    def __init__(self, args):
        QtGui.QApplication.__init__(self, args) 
        self.mywindow = LiveUSBLauncherDialog(args)
        self.mywindow.show()
        self.exec_()

class LiveUSBLauncherDialog(QtGui.QDialog, LiveUSBLauncherInterface):
    """ Our main dialog class """

    def __init__(self, args):
        QtGui.QDialog.__init__(self)
        self.args = args
        self.setupUi(self)
        self.connect_slots()

    def connect_slots(self):
        self.connect(self.cloneInstallButton, QtCore.SIGNAL("clicked()"),
                     self.run_clone_install)
        self.connect(self.cloneUpgradeButton, QtCore.SIGNAL("clicked()"),
                     self.run_clone_upgrade)
        self.connect(self.upgradeFromIsoButton, QtCore.SIGNAL("clicked()"),
                     self.run_upgrade_from_iso)

    def run_live_usb_creator(self, args):
        args = ['liveusb-creator'] + args + self.args
        os.execvp('liveusb-creator', args)

    def run_clone_install(self):
        self.run_live_usb_creator([ '-u', '-n', '--clone', '-P', '-m', '-x' ])

    def run_clone_upgrade(self):
        self.run_live_usb_creator([ '-u', '-n', '-x', '--clone' ])

    def run_upgrade_from_iso(self):
        self.run_live_usb_creator([ '-u', '-n', '-x' ])
