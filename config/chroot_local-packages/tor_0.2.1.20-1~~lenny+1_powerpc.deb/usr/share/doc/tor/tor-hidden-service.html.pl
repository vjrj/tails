<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/1998/REC-html40-19980424/loose.dtd">
<html>
<head>
  <title>Tor: Instrukcja konfiguracji usług ukrytych</title>
  <meta name="Author" content="Roger Dingledine">
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" type="text/css" href="../stylesheet-ltr.css">
  <link rel="shortcut icon" type="image/x-icon" href="../favicon.ico">
</head>
<body>
<div class="center">
<table class="banner" border="0" cellpadding="0" cellspacing="0" summary="">
    <tr>
        <td class="banner-left"><a href="https://www.torproject.org/"><img src="../images/top-left.png" alt="Click to go to home page" width="193" height="79"></a></td>
        <td class="banner-middle">
	<a href="../index.html.pl">Strona główna</a>
<a href="../overview.html.pl">Wprowadzenie</a>
<a href="../easy-download.html.pl">Pobieranie plików</a>
<a href="../documentation.html.pl">Dokumentacja</a>
<a href="../volunteer.html.pl">Wolontariusze</a>
<a href="../people.html.pl">Ludzie</a>
<a href="https://blog.torproject.org/">Blog</a>
<a href="../donate.html.pl">Dotacje</a>
        </td>
        <td class="banner-right">
	<a href="tor-hidden-service.html.de"><acronym title="Deutsch"><img src="../images/de.png" alt="Deutsch" width="24" height="16"></acronym></a> <a href="tor-hidden-service.html.en"><acronym title="English"><img src="../images/en.png" alt="English" width="24" height="16"></acronym></a> <a href="tor-hidden-service.html.es"><acronym title="espa&ntilde;ol"><img src="../images/es.png" alt="espa&ntilde;ol" width="24" height="16"></acronym></a> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <a href="tor-hidden-service.html.fr"><acronym title="fran&ccedil;ais"><img src="../images/fr.png" alt="fran&ccedil;ais" width="24" height="16"></acronym></a> <a href="tor-hidden-service.html.it"><acronym title="Italiano"><img src="../images/it.png" alt="Italiano" width="24" height="16"></acronym></a> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <acronym title="polski"><img src="../images/pl.png" alt="polski" width="24" height="16"></acronym> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <a href="tor-hidden-service.html.ru"><acronym title="&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081;&nbsp;(Russkij)"><img src="../images/ru.png" alt="&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081;&nbsp;(Russkij)" width="24" height="16"></acronym></a> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <a href="tor-hidden-service.html.zh-cn"><acronym title="&#20013;&#25991;(&#31616;) (Simplified Chinese)"><img src="../images/zh-cn.png" alt="&#20013;&#25991;(&#31616;) (Simplified Chinese)" width="24" height="16"></acronym></a>
        </td>
    </tr>
</table>
<div class="center">
<div class="main-column">
<h1>Konfiguracja usług ukrytych <a href="../index.html.pl">Tora</a></h1>
<hr>
<p>Tor umożliwia klientom i przekaźnikom sieci Tor oferowanie usług ukrytych. To znaczy,
 że możesz mieć serwer WWW, SSH etc. bez podawania swojego IP użytkownikom.
 Ponieważ nie używasz żadnego adresu publicznego, możesz prowadzić
 usługę ukrytą zza zapory ogniowej.
</p>
<p>Jeśli masz zainstalowanego Tora i Privoxy, możesz zobaczyć usługi
 ukryte w działaniu, odwiedzając <a href="http://duskgytldkxiuqc6.onion/">naszą przykładową
 usługę ukrytą</a> lub <a
 href="http://gaddbiwdftapglkq.onion/">usługę ukrytą Wikileaks</a>.
</p>
<p>Ten dokument opisuje kroki potrzebne do uruchomienia własnej ukrytej usługi WWW.
By poznać szczegóły techniczne tego, jak działa protokół usług ukrytych, przeczytaj
naszą stronę <a href="../hidden-services.html.pl">protokołu usług ukrytych</a>.
</p>
<hr>
<a id="zero"></a>
<h2><a class="anchor" href="#zero">Krok 0: Uruchomienie Tora i Privoxy</a></h2>
<br>
<p>Zanim zaczniesz sprawdź, czy:</p>
<ol>
<li> Tor jest uruchomiony i działa,</li>
<li> Privoxy jest uruchomione i działa,</li>
<li> Privoxy jest skonfigurowane na Tora</li>
<li> rzeczywiście wszystko dobrze ustawiłeś.</li>
</ol>
<p>Użytkownicy Windows powinni przeczytać <a
 href="../docs/tor-doc-windows.html.pl">instrukcje dla
 Windows</a>, użytkownicy OS X powinni przeczytać <a
 href="../docs/tor-doc-osx.html.pl">instrukcje dla
 OS X</a>, a użytkownicy Linux/BSD/Unix powinni przeczytać <a
 href="../docs/tor-doc-unix.html.pl">instrukcje dla systemów Unix</a>.
</p>
<p>Po instalacji i konfiguracji Tora i Privoxy możesz zobaczyć ukryte usługi
 w działaniu, wchodząc na <a
 href="http://duskgytldkxiuqc6.onion/">naszą przykładową
 usługę ukrytą</a> lub <a
 href="http://gaddbiwdftapglkq.onion/">usługę ukrytą Wikileaks</a>.
 Zwykle trzeba poczekać 10-60 na załadowanie strony (lub stwierdzenie, że w
 danej chwili jest niedostępna). Jeśli próba od razu kończy się błędem mówiącym, że
 nie można znaleźć serwera "www.duskgytldkxiuqc6.onion", to znaczy, że nie skonfigurowałeś
 Tora i Privoxy poprawnie; zajrzyj do <a
 href="https://wiki.torproject.org/noreply/TheOnionRouter/TorFAQ#ItDoesntWork">wpisu
 "to nie działa" w FAQ</a> po pomoc.
</p>
<hr>
<a id="one"></a>
<h2><a class="anchor" href="#one">Krok 1: Zainstaluj lokalnie serwer WWW</a></h2>
<br>
<p>Teraz gdy już masz działające usługi ukryte w Torze, musisz uruchomić
 lokalnie serwer WWW. Uruchamianie serwera WWW jest skomplikowane,
 więc podamy tu tylko trochę podstawowych informacji. Jeśli utkniesz
 lub będziesz chciał zrobić coś więcej, znajdź znajomego, który ci pomoże.
 Zalecamy instalację nowego, oddzielnego serwera do usługi ukrytej, gdyż
 nawet jeśli już masz jeden zainstalowany, możesz już go używać (lub
 później będziesz chciał go używać) do normalnego serwisu WWW.
</p>
<p>Jeśli jesteś na systemie Unix lub OS X i nie przeszkadza ci używanie
 linii poleceń, najlepszym sposobem jest instalacja <a
 href="http://www.acme.com/software/thttpd/">thttpd</a>. Po prostu
 pobierz archiwum tar, rozpakuj je (utworzy się osobny katalog) i uruchom
 <kbd>./configure &amp;&amp; make</kbd>. Potem wykonaj <kbd>mkdir hidserv; cd hidserv</kbd>,
 i uruchom <kbd>../thttpd -p 5222 -h localhost</kbd>. Powrócisz do wiersza poleceń,
 a od tej pory masz uruchomiony serwer WWW na porcie 5222. Możesz umieścić
 pliki dla serwera w katalogu hidserv.
</p>
<p>Jeśli używasz systemu Windows, możesz wybrać serwer WWW <a
 href="http://savant.sourceforge.net/">Savant</a> lub <a
 href="http://httpd.apache.org/">Apache</a>,
 konfigurując go tak, by podłączał się tylko do komputera, na którym jest
 zainstalowany (localhost). Powinieneś też jakoś sprawdzić na jakim porcie
 nasłuchuje, gdyż ta informacja przyda się potem.
</p>
<p>(Powodem, dla którego serwer powinien działać tylko lokalnie jest upewnienie
 się, że nie jest on dostępny z zewnątrz. Jeśli ktoś mógłby się do niego
 połączyć bezpośrednio, mógłby potwierdzić, że to twój komputer oferuje
 tą ukrytą usługę.)
</p>
<p>Po ustawieniu serwera WWW, sprawdź, czy działa: otwórz przeglądarkę i
 przejdź pod adres <a
 href="http://localhost:5222/">http://localhost:5222/</a>, gdzie 5222 jest numerem portu
 wybranym wcześniej. Potem spróbuj
 umieścić jakiś plik w głównym katalogu HTML serwera i sprawdź, czy pokazuje
 się on, gdy łączysz się ze swoim serwerem WWW.
</p>
<hr>
<a id="two"></a>
<h2><a class="anchor" href="#two">Krok 2: Konfiguracja twojej usługi ukrytej</a></h2>
<br>
<p>Teraz musisz skonfigurować swoją usługę ukrytą, by wskazywała na twój lokalny
 serwer WWW.
</p>
<p>Najpierw otwórz swój plik torrc swoim ulubionym edytorem. (Przeczytaj <a
 href="https://wiki.torproject.org/noreply/TheOnionRouter/TorFAQ#torrc">wpis
 o torrc w FAQ</a>, by dowiedzieć się, co to znaczy.) Przejdź do środkowej sekcji i
 szukaj linii</p>
<pre>
############### This section is just for location-hidden services ###
</pre>
<p>Ta sekcja pliku składa się z grup linii, z których każda reprezentuje
 jedną usługę ukrytą. W tej chwili wszystkie są zakomentowane (linie zaczynają
 się od krzyżyka #), więc usługi ukryte są wyłączone. Każda grupa linii
 składa się z jednej linii <var>HiddenServiceDir</var> i jednej lub więcej linii
 <var>HiddenServicePort</var>:</p>
<ul>
<li><var>HiddenServiceDir</var> jest katalogiem, w którym Tor będzie przechowywał
 informacje o tej usłudze ukrytej. W szczególności, Tor utworzy w tym katalogu
 plik o nazwie <var>hostname</var>, z którego odczytasz "adres cebulowy" (onion URL).
 Nie musisz dodawać żadnych plików do tego katalogu.</li>
<li><var>HiddenServicePort</var> pozwala określić port wirtualny (tzn. użytkownikom
 łączącym się z usługą ukrytą będzie się zdawało, że używają tego właśnie portu) i
 adres IP wraz z portem do przekierowywania połączeń na ten wirtualny port.</li>
</ul>
<p>Dodaj następujące linie do swojego pliku torrc:
</p>
<pre>
HiddenServiceDir /Library/Tor/var/lib/tor/hidden_service/
HiddenServicePort 80 127.0.0.1:5222
</pre>
<p>Powinieneś zmienić linię <var>HiddenServiceDir</var> tak, by pokazywała na istniejący
 katalog, który jest odczytywalny/zapisywalny przez użytkownika, który uruchamia
 Tora. Powyższa linia powinna działać, gdy używasz paczki z Torem dla OS X.
 Pod systemem Unix, sprobuj "/home/użytkownik/hidserv/", podając własną nazwę użytkownika
 w miejsce "użytkownik". Pod systemem Windows mógłbyś wpisać:</p>
<pre>
HiddenServiceDir C:\Documents and Settings\username\Application Data\hidden_service\
HiddenServicePort 80 127.0.0.1:5222
</pre>
<p>Teraz zapisz zmiany w pliku torrc, zamknij Tora i uruchom go ponownie.
</p>
<p>Jeśli Tor ponownie się uruchomi, to świetnie. W innym przypadku coś musi być
 źle. Najpierw przejrzyj plik z logami, by poszukać przyczyn. Będą w nim
 ostrzeżenia i błędy. Powinny one wskazać, co poszło nie tak. Zazwyczaj chodzi o
 literówki w pliku torrc lub złe uprawnienia do katalogów. (Przeczytaj <a
 href="https://wiki.torproject.org/noreply/TheOnionRouter/TorFAQ#Logs">wpis
 o logach w FAQ</a>, jeśli nie wiesz jak włączyć lub znaleźć plik z logami.)
</p>
<p>Gdy Tor się uruchomi, automatycznie utworzy podany katalog <var>HiddenServiceDir</var>
 (jeśli trzeba), a w nim utworzy dwa pliki.</p>
 <dl>
 <dt><var>private_key</var></dt>
 <dd>Po pierwsze, Tor wygeneruje nową
 parę kluczy publiczny/prywatny do twojej usługi ukrytej. Zostaje ona zapisana w
 pliku o nazwie "private_key". Nie dawaj tego klucza nikomu -- jeśli to zrobisz,
 inni będą mogli podszyć się pod twoją usługę ukrytą.</dd>
 <dt><var>hostname</var></dt>
 <dd>Drugim plikiem, który zostanie utworzony, jest plik o nazwie "hostname".
 Zawiera on krótkie podsumowanie twojego klucza publicznego -- będzie wyglądać
 podobnie do tego: <tt>duskgytldkxiuqc6.onion</tt>. To jest publiczna nazwa
 twojej usługi i możesz podawać ją innym, rozgłaszać w internecie,
 umieszczać na wizytówkach etc.</dd>
 </dl>
<p>Jeśli Tor jest uruchomiony z prawami innego
 użytkownika niż ty, np. na systemach OS X, Debian, Red Hat, możesz potrzebować
 uprawnień roota, by zobaczyć te pliki.
</p>
<p>Po ponownym uruchomieniu, Tor zajmuje się pobieraniem punktów wstępu
 w sieci Tora i generowaniem <em>deskryptorem usługi ukrytej</em>.
 Jest to podpisana lista punktów wstępnych razem z pełnym publicznym kluczem
 usługi. Tor anonimowo umieszcza ten deskryptor na serwerach katalogowych, a
 inni ludzie anonimowo go pobierają z serwerów katalogowych, gdy próbują połączyć
 się z twoją usługą.
</p>
<p>Wypróbuj to: wklej zawartość pliku "hostname" do swojej przeglądarki WWW.
 Jeśli działa, zobaczysz stronę Google, ale adres w przeglądarce będzie
 adresem twojej usługi. Jeśli nie działa, poszukaj wskazówek w logach i
 zajmuj się tym do chwili, w której zadziała.
</p>
<hr>
<a id="three"></a>
<h2><a class="anchor" href="#three">Krok 3: Wskazówki dla zaawansowanych</a></h2>
<br>
<p>Jeśli planujesz udostępniać swoją usługę przez dłuższy czas, zrób kopię
 zapasową pliku <var>private_key</var>.
</p>
<p>Wcześniej unikaliśmy polecania serwera Apache, a) gdyż wielu ludzi
 może już go używać jako publicznego serwera na ich komputerach, i
 b) gdyż jest duży i ma wiele miejsc, w których mógłby podać twój adres IP
 lub inne informacje identyfikujące, np. na stronach 404. Jednak dla ludzi,
 którzy chcą więcej funkcjonalności, Apache może być dobrym rozwiązaniem.
 Czy ktoś mógłby napisać nam listę sposobów na zabezpieczenie Apache, gdy
 jest używany jako usługa ukryta? Savant prawdopodobnie też ma takie problemy.
</p>
<p>Jeśli chcesz przekierować wiele portów wirtualnych w ramach pojedynczej
 usługi ukrytej, po prostu dodaj więcej linii <var>HiddenServicePort</var>.
 Jeśli chcesz uruchomić wiele usług ukrytych z tego samego klienta Tora,
 po prostu dodaj kolejną linię <var>HiddenServiceDir</var>. Wszystkie następujące po
 niej linie <var>HiddenServicePort</var> odnoszą się do aktualnej linii <var>HiddenServiceDir</var>,
 dopóki nie dodasz kolejnej linii <var>HiddenServiceDir</var>:
</p>
<pre>
HiddenServiceDir /usr/local/etc/tor/hidden_service/
HiddenServicePort 80 127.0.0.1:8080

HiddenServiceDir /usr/local/etc/tor/other_hidden_service/
HiddenServicePort 6667 127.0.0.1:6667
HiddenServicePort 22 127.0.0.1:22
</pre>
<p>Są też pewne sprawy dotyczące anonimowości, o których trzeba pamiętać:
</p>
<ul>
<li>Jak wspomniano wyżej, uważaj z pozwoleniem dla serwera o podawaniu
 informacji identyfikujących ciebie, twój komputer lub położenie.
 Na przykład, czytelnicy mogą prawdopodobnie dowiedzieć się, czy
 używasz Apache czy thttpd i dowiedzieć sie czegoś o twoim systemie operacyjnym.</li>
<li>Jeśli twój komputer nie jest cały czas on-line, twoja usługa ukryta też
 nie będzie. Jest to wyciek informacji dla obserwującego przeciwnika.</li>
<!-- increased risks over time -->
</ul>
<hr>
<p>Jeśli masz pomysły na ulepszenie tej strony, prosimy <a
href="../contact.html.pl">je do nas wysłać</a>. Dziękujemy!</p>
  </div><!-- #main -->
</div>
<hr>
</div>
  <div class="bottom" id="bottom">
     <p>"Tor" i "Onion Logo" (logo cebuli) są <a href="../trademark-faq.html.pl">zarejestrowanymi znakami handlowymi</a> The Tor Project, Inc.<br>
	Zawartość tej strony jest pod licencją
	<a href="http://creativecommons.org/licenses/by/3.0/us/">Creative Commons Attribution
	3.0 United States License</a>, chyba że napisano inaczej.
	</p>
     <p>
       Ta strona jest także dostępna w następujących językach:
       <a href="tor-hidden-service.html.de">Deutsch</a>, <a href="tor-hidden-service.html.en">English</a>, <a href="tor-hidden-service.html.es">espa&ntilde;ol</a>, <a href="tor-hidden-service.html.fr">fran&ccedil;ais</a>, <a href="tor-hidden-service.html.it">Italiano</a>, <a href="tor-hidden-service.html.ru">&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081;&nbsp;(Russkij)</a>, <a href="tor-hidden-service.html.zh-cn">&#20013;&#25991;(&#31616;) (Simplified Chinese)</a>.<br>
       Jak ustawić <a href="http://www.debian.org/intro/cn.pl.html#howtoset">domyślny język dokumentu</a>.
     </p>
 <p>
 Deweloperzy Tora nie sprawdzili tłumaczenia tej strony pod względem dokładności
  i poprawności. Tłumaczenie może być przestarzałe lub niepoprawne. Oficjalna strona Tora jest
  po angielsku, pod adresem <a href="https://www.torproject.org/">https://www.torproject.org/</a>.
 </p>
     <p>
     <i><a href="../contact.html.pl" class="smalllink">Webmaster</a></i> -
      Ostatnio zmodyfikowane: Sun Jul 19 06:26:25 2009
      -
      Ostatnio wygenerowane: Sun Oct 18 00:34:00 2009
     </p>
  </div>
</body>
</html>
