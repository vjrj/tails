=head1 NAME

Tails::Persistence::Configuration::Line - read, parse and write live-persistence.conf lines

=cut

package Tails::Persistence::Configuration::Line;

use Moose;
with 'Tails::Persistence::Role::ConfigurationLine';

our $VERSION = '0.13'; # VERSION

no Moose;
1;
