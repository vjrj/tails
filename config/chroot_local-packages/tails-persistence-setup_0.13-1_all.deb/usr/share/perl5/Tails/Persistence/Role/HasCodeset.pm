=head1 NAME

Tails::Persistence::Role::HasCodeset - role to get the codeset being used

=head1 SYNOPSIS

    use MooseX::Declare;
    class Tails::Persistence::Daemon with Tails::Persistence::Role::HasCodeset {
      ...
    }

    See Tails::Persistence::Daemon for a real-life usage example.

=cut

package Tails::Persistence::Role::HasCodeset;
use Moose::Role;

our $VERSION = '0.13'; # VERSION

use namespace::autoclean;
use Try::Tiny;

has 'codeset'  => (
    isa        => 'Str',
    is         => 'ro',
    lazy_build => 1,
);

sub _build_codeset {
    my $codeset;
    try {
        require I18N::Langinfo;
        I18N::Langinfo->import(qw(langinfo CODESET));
        $codeset = langinfo(CODESET());
    } catch {
        die "No default character code set configured.\nPlease fix your locale settings.";
    };
    $codeset;
}

no Moose::Role;
1; # End of Tails::Persistence::Role::HasCodeset
