=head1 NAME

Tails::Persistence::Configuration::Button - a configuration button in the GUI

=cut

package Tails::Persistence::Configuration::Button;
use Moose;
use MooseX::Method::Signatures;
use MooseX::Types::Moose qw( :all );
use MooseX::Has::Sugar::Saccharin;

our $VERSION = '0.7'; # VERSION

use autodie qw(:all);
use warnings FATAL => 'all';
use Glib qw{TRUE FALSE};


=head1 ATTRIBUTES

=cut

has 'atom'         => lazy_build ro 'Tails::Persistence::Configuration::Atom',
    handles => [
        qw{source destination all_options enabled name description icon_id}
    ];
has 'icon'         => lazy_build ro 'Gtk2::Image';
has 'checked_img'  => lazy_build ro 'Gtk2::Image';
has 'main_widget'  => lazy_build ro 'Gtk2::ToggleButton';
has 'icon_factory' => ro 'Gtk2::IconFactory', builder '_build_icon_factory';


=head1 CONSTRUCTORS

=cut

method _build_icon {
    Gtk2::Image->new_from_stock($self->icon_id, 'large-toolbar');
}

method _build_checked_img {
    Gtk2::Image->new_from_stock('gtk-apply', 'small-toolbar');
}

method _build_main_widget {
    my $line = shift;

    my $title = Gtk2::Label->new($self->name);
    $title->set_alignment(0.0, 0.5);
    my $title_attrlist  = Pango::AttrList->new;
    $title_attrlist->insert($_)
        foreach ( Pango::AttrScale->new(1.1),Pango::AttrWeight->new('bold') );
    $title->set_attributes($title_attrlist);

    my $description = Gtk2::Label->new($self->description);
    $description->set_alignment(0.0, 0.5);
    my $description_attrlist = Pango::AttrList->new;
    $description_attrlist->insert(
        Pango::AttrForeground->new(30000, 30000, 30000)
      );
    $description->set_attributes($description_attrlist);
    $description->set_line_wrap(TRUE);
    $description->set_line_wrap_mode('word');
    $description->set_single_line_mode(FALSE);

    my $vbox = Gtk2::VBox->new();
    $vbox->set_border_width(5);
    $vbox->pack_start($title, FALSE, FALSE, 0);
    $vbox->pack_start($description, FALSE, FALSE, 0);

    my $hbox = Gtk2::HBox->new();
    $hbox->pack_start($self->icon, FALSE, FALSE, 0);
    $hbox->pack_start($vbox, FALSE, FALSE, 0);
    $hbox->pack_start($self->checked_img, FALSE, FALSE, 0);

    my $button = Gtk2::ToggleButton->new();
    $button->add($hbox);
    $button->set_active($self->enabled);

    return $button;
}

method _build_icon_factory {
    my $factory = Gtk2::IconFactory->new();
    $factory->add_default;

    my $question_set    = Gtk2::IconSet->new();
    my $question_source = Gtk2::IconSource->new();
    $question_source->set_filename(
        # '/usr/share/icons/gnome/48x48/status/dialog-question.png'
        '/usr/share/icons/gnome/scalable/status/dialog-question-symbolic.svg'
    );
    $question_source->set_direction_wildcarded(1);
    $question_source->set_state_wildcarded(1);
    $question_source->set_size('dialog');
    $question_set->add_source($question_source);

    $factory->add('tails-persistence-setup-unknown', $question_set);

    return $factory;
}


no Moose;
1;
