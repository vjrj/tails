=head1 NAME

Tails::Persistence::Step::Configure - configure which bits are persistent

=cut

package Tails::Persistence::Step::Configure;
use Moose;
use MooseX::Method::Signatures;
use MooseX::Types::Moose qw( :all );
use MooseX::Has::Sugar::Saccharin;

our $VERSION = '0.7'; # VERSION

use Glib qw{TRUE FALSE};

use Number::Format qw(:subs);
use Try::Tiny;

use Locale::gettext;
use POSIX;
setlocale(LC_MESSAGES, "");
textdomain("tails-persistence-setup");


=head1 ATTRIBUTES

=cut

has 'configuration' => lazy_build rw 'Tails::Persistence::Configuration';

has 'persistence_partition'      => required ro Str;
has 'persistence_partition_size' => required ro Int;

has 'list_box' => lazy_build ro 'Gtk2::VBox';

has 'buttons'  =>
    lazy_build ro 'ArrayRef[Tails::Persistence::Configuration::Button]',
    traits  => [ 'Array' ],
    handles => { all_buttons => 'elements' };



=head1 CONSTRUCTORS

=cut

sub BUILD {
    my $self = shift;

    $self->title->set_text($self->encoding->decode(gettext(
        q{Persistence wizard - Configuration}
    )));
    $self->subtitle->set_text($self->encoding->decode(gettext(
        q{Decide which files should persist}
    )));
    # TRANSLATORS: partition, size, device vendor, device model
    $self->description->set_markup($self->encoding->decode(sprintf(
        gettext(q{The selected files will be stored on the Tails persistence partition %s (%s), on the <b>%s %s</b> device.}),
        $self->persistence_partition,
        format_bytes($self->persistence_partition_size, mode => "iec"),
        $self->device_vendor,
        $self->device_model
    )));
    $self->go_button->set_label($self->encoding->decode(gettext(q{Save})));
    $self->go_button->set_sensitive(TRUE);
}

method _build_main_box {
    my $box = Gtk2::VBox->new();
    $box->set_spacing(6);
    $box->pack_start($self->title, FALSE, FALSE, 0);
    $box->pack_start($self->subtitle, FALSE, FALSE, 0);
    $box->pack_start($self->description, FALSE, FALSE, 0);
    $box->pack_start($self->list_box, FALSE, FALSE, 0);

    $box->pack_start($self->status_area, FALSE, FALSE, 0);

    my $button_alignment = Gtk2::Alignment->new(1.0, 0, 0.2, 1.0);
    $button_alignment->set_padding(0, 0, 10, 10);
    $button_alignment->add($self->go_button);
    $box->pack_start($button_alignment, FALSE, FALSE, 0);

    return $box;
}

method _build_buttons {
    map {
        Tails::Persistence::Configuration::Button->new(atom => $_)
    } $self->configuration->all_atoms;
}

method _build_list_box {
    my $box = Gtk2::VBox->new();
    $box->set_spacing(6);
    $box->pack_start($_, FALSE, FALSE, 0) foreach $self->all_buttons;

    return $box;
}


=head1 METHODS

=cut

method operation_finished ($error) {
    if ($error) {
        $self->working(0);
        say STDERR "$error";
        $self->subtitle->set_text($self->encoding->decode(gettext(q{Failed})));
        $self->description->set_text($error);
    }
    else {
        say STDERR "done.";
        $self->working(0);
        $self->success_callback->();
    }
}

method go_button_pressed {
    $self->list_box->hide;
    $self->working(1);
    $self->subtitle->set_text(
        $self->encoding->decode(gettext(q{Saving...})),
    );
    $self->description->set_text(
        $self->encoding->decode(gettext(q{Saving persistence configuration...})),
    );

    my $error;
    try {
        $self->go_callback->();
    } catch {
        $error = $@;
    };
    $self->operation_finished($error);
}

with 'Tails::Persistence::Role::StatusArea';
with 'Tails::Persistence::Role::SetupStep';

no Moose;
1;
