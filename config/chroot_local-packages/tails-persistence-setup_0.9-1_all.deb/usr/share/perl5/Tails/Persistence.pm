=head1 NAME

Tails::Persistence - main placeholder module

=cut

use strict;
use warnings FATAL => 'all';
use 5.10.0;

our $VERSION = '0.9'; # VERSION

1;
