=head1 NAME

Tails::Persistence::Configuration::Atom - a GUI-friendly configuration line

=cut

package Tails::Persistence::Configuration::Atom;
use Moose;
use MooseX::Method::Signatures;
use MooseX::Types::Moose qw( :all );
use MooseX::Has::Sugar::Saccharin;

our $VERSION = '0.9'; # VERSION

with 'Tails::Persistence::Role::ConfigurationLine';
with 'Tails::Persistence::Role::HasEncoding';

use autodie qw(:all);
use warnings FATAL => 'all';

use List::MoreUtils qw{all pairwise};

use Locale::gettext;
use POSIX;
setlocale(LC_MESSAGES, "");
textdomain("tails-persistence-setup");


=head1 ATTRIBUTES

=cut

has 'enabled'     => required rw Bool;
has 'name'        => lazy_build rw Str;
has 'description' => lazy_build rw Str;
has 'icon_name'     => lazy_build rw Str;


=head1 CONSTRUCTORS

=cut

sub new_from_line {
    my $class = shift;
    my $line  = shift;
    my %args  = @_;

    Tails::Persistence::Configuration::Atom->new(
        source      => $line->source,
        destination => $line->destination,
        options     => $line->options,
        %args,
    );
}

method _build_name { $self->encoding->decode(gettext('Custom')); }

method _build_description {
    $self->encoding->decode(sprintf(
        gettext('%s on %s'), $self->source, $self->destination
    ));
}

method _build_icon_name { 'dialog-question' }


=head1 METHODS

=cut


method equals_line ($line) {
    $self->source      eq $line->source
        and
    $self->destination eq $line->destination
        and
    $self->options_are($line->all_options);
}

sub options_are {
    my $self = shift;

    my @expected = sort(@_);
    my @options  = sort($self->all_options);

    return unless @expected == @options;

    # all {} returns true in List::MoreUtils 0.27~04 and later.
    # It previously did not, and Squeeze has 0.25~02, so take care
    # of empty equal lists ourselves.
    return 1 unless @options;

    all { $_ } pairwise {
        defined($a) and defined($b) and $a eq $b
    } @expected, @options;
}

no Moose;
1;
