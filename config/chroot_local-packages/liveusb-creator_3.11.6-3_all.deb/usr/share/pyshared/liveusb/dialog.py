# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'data/liveusb-creator.ui'
#
# Created: Wed Apr 25 18:41:07 2012
#      by: PyQt4 UI code generator 4.9.1
#
# WARNING! All changes made in this file will be lost!


import sys
if sys.platform == "win32":
    from liveusb import utf8_gettext as _
else:
    from liveusb import _
from liveusb import branding

def translate_and_brand(string):
    return _(string) % branding

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(422, 388)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Fixed, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Dialog.sizePolicy().hasHeightForWidth())
        Dialog.setSizePolicy(sizePolicy)
        Dialog.setMinimumSize(QtCore.QSize(0, 0))
        Dialog.setBaseSize(QtCore.QSize(422, 388))
        self.layoutWidget = QtGui.QWidget(Dialog)
        self.layoutWidget.setGeometry(QtCore.QRect(0, 0, 421, 381))
        self.layoutWidget.setObjectName(_fromUtf8("layoutWidget"))
        self.verticalLayout = QtGui.QVBoxLayout(self.layoutWidget)
        self.verticalLayout.setSizeConstraint(QtGui.QLayout.SetDefaultConstraint)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.titleLabel = QtGui.QLabel(self.layoutWidget)
        self.titleLabel.setText(_fromUtf8(""))
        self.titleLabel.setObjectName(_fromUtf8("titleLabel"))
        self.verticalLayout.addWidget(self.titleLabel)
        self.sourceHorizontalLayout = QtGui.QHBoxLayout()
        self.sourceHorizontalLayout.setSpacing(6)
        self.sourceHorizontalLayout.setSizeConstraint(QtGui.QLayout.SetDefaultConstraint)
        self.sourceHorizontalLayout.setObjectName(_fromUtf8("sourceHorizontalLayout"))
        self.sourceFileGroupBox = QtGui.QGroupBox(self.layoutWidget)
        self.sourceFileGroupBox.setMinimumSize(QtCore.QSize(161, 51))
        self.sourceFileGroupBox.setBaseSize(QtCore.QSize(161, 51))
        font = QtGui.QFont()
        font.setPointSize(8)
        self.sourceFileGroupBox.setFont(font)
        self.sourceFileGroupBox.setObjectName(_fromUtf8("sourceFileGroupBox"))
        self.isoBttn = QtGui.QPushButton(self.sourceFileGroupBox)
        self.isoBttn.setGeometry(QtCore.QRect(11, 18, 141, 25))
        self.isoBttn.setObjectName(_fromUtf8("isoBttn"))
        self.sourceHorizontalLayout.addWidget(self.sourceFileGroupBox)
        self.orLabel = QtGui.QLabel(self.layoutWidget)
        self.orLabel.setMinimumSize(QtCore.QSize(23, 24))
        self.orLabel.setBaseSize(QtCore.QSize(23, 24))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Verdana"))
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.orLabel.setFont(font)
        self.orLabel.setAlignment(QtCore.Qt.AlignCenter)
        self.orLabel.setObjectName(_fromUtf8("orLabel"))
        self.sourceHorizontalLayout.addWidget(self.orLabel)
        self.downloadGroupBox = QtGui.QGroupBox(self.layoutWidget)
        self.downloadGroupBox.setMinimumSize(QtCore.QSize(201, 51))
        self.downloadGroupBox.setBaseSize(QtCore.QSize(201, 51))
        font = QtGui.QFont()
        font.setPointSize(8)
        self.downloadGroupBox.setFont(font)
        self.downloadGroupBox.setObjectName(_fromUtf8("downloadGroupBox"))
        self.downloadCombo = QtGui.QComboBox(self.downloadGroupBox)
        self.downloadCombo.setGeometry(QtCore.QRect(10, 20, 181, 22))
        self.downloadCombo.setObjectName(_fromUtf8("downloadCombo"))
        self.sourceHorizontalLayout.addWidget(self.downloadGroupBox)
        self.verticalLayout.addLayout(self.sourceHorizontalLayout)
        self.targetHorizontalLayout = QtGui.QHBoxLayout()
        self.targetHorizontalLayout.setSpacing(10)
        self.targetHorizontalLayout.setObjectName(_fromUtf8("targetHorizontalLayout"))
        self.targetGroupBox = QtGui.QGroupBox(self.layoutWidget)
        self.targetGroupBox.setMinimumSize(QtCore.QSize(191, 51))
        self.targetGroupBox.setBaseSize(QtCore.QSize(191, 51))
        font = QtGui.QFont()
        font.setPointSize(8)
        self.targetGroupBox.setFont(font)
        self.targetGroupBox.setObjectName(_fromUtf8("targetGroupBox"))
        self.driveBox = QtGui.QComboBox(self.targetGroupBox)
        self.driveBox.setGeometry(QtCore.QRect(10, 20, 171, 22))
        self.driveBox.setEditable(False)
        self.driveBox.setInsertPolicy(QtGui.QComboBox.InsertAtTop)
        self.driveBox.setDuplicatesEnabled(False)
        self.driveBox.setObjectName(_fromUtf8("driveBox"))
        self.targetHorizontalLayout.addWidget(self.targetGroupBox)
        self.overlayTitle = QtGui.QGroupBox(self.layoutWidget)
        self.overlayTitle.setMinimumSize(QtCore.QSize(0, 0))
        self.overlayTitle.setBaseSize(QtCore.QSize(201, 51))
        font = QtGui.QFont()
        font.setPointSize(8)
        self.overlayTitle.setFont(font)
        self.overlayTitle.setObjectName(_fromUtf8("overlayTitle"))
        self.overlaySlider = QtGui.QSlider(self.overlayTitle)
        self.overlaySlider.setGeometry(QtCore.QRect(10, 20, 181, 21))
        self.overlaySlider.setMaximum(2047)
        self.overlaySlider.setOrientation(QtCore.Qt.Horizontal)
        self.overlaySlider.setTickPosition(QtGui.QSlider.NoTicks)
        self.overlaySlider.setObjectName(_fromUtf8("overlaySlider"))
        self.targetHorizontalLayout.addWidget(self.overlayTitle)
        self.verticalLayout.addLayout(self.targetHorizontalLayout)
        self.textEdit = QtGui.QTextEdit(self.layoutWidget)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.textEdit.sizePolicy().hasHeightForWidth())
        self.textEdit.setSizePolicy(sizePolicy)
        self.textEdit.setMinimumSize(QtCore.QSize(401, 111))
        self.textEdit.setBaseSize(QtCore.QSize(401, 111))
        font = QtGui.QFont()
        font.setPointSize(8)
        self.textEdit.setFont(font)
        self.textEdit.setReadOnly(True)
        self.textEdit.setObjectName(_fromUtf8("textEdit"))
        self.verticalLayout.addWidget(self.textEdit)
        self.progressBar = QtGui.QProgressBar(self.layoutWidget)
        self.progressBar.setMinimumSize(QtCore.QSize(401, 23))
        self.progressBar.setBaseSize(QtCore.QSize(401, 23))
        self.progressBar.setProperty("value", 0)
        self.progressBar.setObjectName(_fromUtf8("progressBar"))
        self.verticalLayout.addWidget(self.progressBar)
        self.startButton = QtGui.QPushButton(self.layoutWidget)
        self.startButton.setEnabled(True)
        self.startButton.setObjectName(_fromUtf8("startButton"))
        self.verticalLayout.addWidget(self.startButton)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(translate_and_brand('%(distribution)s LiveUSB Creator'))
        self.sourceFileGroupBox.setWhatsThis(translate_and_brand('This button allows you to browse for an existing Live system ISO that you have previously downloaded.  If you do not select one, a release will be downloaded for you automatically.'))
        self.sourceFileGroupBox.setTitle(translate_and_brand('Use existing Live system ISO'))
        self.isoBttn.setText(translate_and_brand('Browse'))
        self.isoBttn.setShortcut(translate_and_brand('Alt+B'))
        self.orLabel.setText(translate_and_brand('or'))
        self.downloadGroupBox.setWhatsThis(translate_and_brand('If you do not select an existing Live ISO, the selected release will be downloaded for you.'))
        self.downloadGroupBox.setTitle(translate_and_brand('Download %(distribution)s'))
        self.targetGroupBox.setWhatsThis(translate_and_brand('This is the USB stick that you want to install your Live system on.  This device must be formatted with the FAT filesystem.'))
        self.targetGroupBox.setTitle(translate_and_brand('Target Device'))
        self.overlayTitle.setWhatsThis(translate_and_brand('By allocating extra space on your USB stick for a persistent overlay, you will be able to store data and make permanent modifications to your live operating system.  Without it, you will not be able to save data that will persist after a reboot.'))
        self.overlayTitle.setTitle(translate_and_brand('Persistent Storage (0 MB)'))
        self.textEdit.setWhatsThis(translate_and_brand('This is the status console, where all messages get written to.'))
        self.progressBar.setWhatsThis(translate_and_brand('This is the progress bar that will indicate how far along in the LiveUSB creation process you are'))
        self.startButton.setWhatsThis(translate_and_brand('This button will begin the LiveUSB creation process.  This entails optionally downloading a release (if an existing one wasn\'t selected),  extracting the ISO to the USB device, creating the persistent overlay, and installing the bootloader.'))
        self.startButton.setText(translate_and_brand('Create Live USB'))

import resources_rc
