# -*- coding: utf-8 -*-

import os

from configobj import ConfigObj

config_files = [ os.path.join('/', 'etc', 'liveusb-creator', f )
                 for f in [ 'defaults.ini', 'vendor.ini', 'site.ini' ] ]

# XXX: move defaults to a proper defaults.ini file?
default_config = {
    'main_liveos_dir': 'live',
    'running_liveos_mountpoint': '/live/image',
    'liveos_toplevel_files': [ 'autorun.bat', 'autorun.inf', 'boot', '.disk',
                               'doc', 'live', 'isolinux', 'syslinux' ],
    'download': { 'enabled': False,
                },
    'persistence': { 'enabled': False,
                },
    'branding': { 'distribution': 'Tails',
                  'header': ':/tails-liveusb-header.png',
                  'partition_label': 'Tails',
                },
}

config = ConfigObj(default_config)

for f in config_files:
    config.merge(ConfigObj(f))
