# -*- coding: utf-8 -*-

import os
import subprocess
import shutil
import stat
import sys
from liveusb import _

def _to_unicode(obj, encoding='utf-8'):
    if hasattr(obj, 'toUtf8'): # PyQt4.QtCore.QString
        obj = str(obj.toUtf8())
    if isinstance(obj, basestring):
        if not isinstance(obj, unicode):
            obj = unicode(obj, encoding)
    return obj

def unicode_to_utf8(string):
    if isinstance(string, unicode):
        return string.encode('utf-8')
    return string

def extract_file_content_from_iso(iso_path, path):
    """ Return the content of that file read from inside self.iso """

    cmd = ['isoinfo', '-R', '-i', unicode_to_utf8(iso_path),
           '-x', unicode_to_utf8(path)]

    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = proc.communicate()
    out = unicode_to_utf8(out)
    err = unicode_to_utf8(err)
    if proc.returncode:
        raise Exception(_("There was a problem executing `%s`."
                          "%s\n%s" % (cmd, out, err)))
    return out

def iso_is_live_system(iso_path):
    """ Return true iff a Live system is detected inside the iso_path file """
    if sys.platform == 'win32':
        return True
    version = extract_file_content_from_iso(iso_path, '/.disk/info')
    return version.startswith('Debian GNU/Linux')

def _dir_size(source):
    total_size = os.path.getsize(source)
    for item in os.listdir(source):
        itempath = os.path.join(source, item)
        if os.path.isfile(itempath):
            total_size += os.path.getsize(itempath)
        elif os.path.isdir(itempath):
            total_size += _dir_size(itempath)
    return total_size

def _move_if_exists(src, dest):
    if os.path.exists(src):
        shutil.move(src, dest)

def _unlink_if_exists(path):
    if os.path.exists(path):
        os.unlink(path)

def _set_liberal_perms_recursive(destination):
    def _set_liberal_perms(arg, dirname, fnames):
        if dirname == 'lost+found':
            return
        os.chmod(dirname, 0755)
        for f in fnames:
            if f == 'lost+found':
                continue
            file = os.path.join(dirname, f)
            if os.path.isdir(file):
                os.chmod(file, 0755)
            elif os.path.isfile(file):
                os.chmod(file, 0644)
    os.path.walk(destination, _set_liberal_perms, None)

def get_udisks_obj(bus):
    return bus.get_object("org.freedesktop.UDisks", "/org/freedesktop/UDisks")

def underlying_physical_device(path):
    """ Returns the physical block device UDI (e.g.
    /org/freedesktop/UDisks/devices/sdb) on which the specified file is stored.
    """
    import dbus
    bus         = dbus.SystemBus()
    rawdev      = os.stat(path)[stat.ST_DEV]
    udisks_obj  = get_udisks_obj(bus)
    udisks      = dbus.Interface(udisks_obj, "org.freedesktop.UDisks")
    dev_path    = udisks.FindDeviceByMajorMinor(os.major(rawdev), os.minor(rawdev))
    dev_obj     = bus.get_object("org.freedesktop.UDisks", dev_path)
    dev         = dbus.Interface(dev_obj, "org.freedesktop.DBus.Properties")
    parent_path = dev.Get(dev_path, 'PartitionSlave')
    if parent_path and parent_path != '/':
        return parent_path
    else:
        return dev_path
