#ifndef ___version_generated_h___
#define ___version_generated_h___

#define VBOX_VERSION_MAJOR 4
#define VBOX_VERSION_MINOR 0
#define VBOX_VERSION_BUILD 4
#define VBOX_VERSION_STRING "4.0.4_OSE"

#endif
