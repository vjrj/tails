#!/bin/bash
setxkbmap -model pc105 -layout gb -variant basic
