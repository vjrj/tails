=head1 NAME

Tails::Persistence::Setup - main application class

=cut

package Tails::Persistence::Setup;
use Moose;
use MooseX::Method::Signatures;
use MooseX::Types::Moose qw( :all );
use MooseX::Types::Path::Class;
use MooseX::Has::Sugar::Saccharin;

our $VERSION = '0.8.2'; # VERSION

with 'Tails::Persistence::Role::HasEncoding';
with 'MooseX::Getopt::Dashes';

use 5.10.0;
use namespace::autoclean;

use autodie qw(:all);
use Data::Dumper;
use Encode;
use English qw{-no_match_vars};
use File::stat;
use Glib qw{TRUE FALSE};
use Gtk2 qw{-init};
use Gtk2::Gdk::Keysyms;
use Net::DBus qw(:typing);
use Net::DBus::GLib;
use Net::DBus::Annotation qw(:call);
use List::Util qw{first max};
use Number::Format qw(:subs);
use Path::Class;
use Tails::Persistence::Utils qw{align_up_at_2MiB align_down_at_2MiB step_name_to_class_name get_variable_from_file};
use Try::Tiny;
use Unix::Mknod qw(:all);

use Tails::Persistence::Configuration;

use Tails::Persistence::Step::Bootstrap;
use Tails::Persistence::Step::Configure;
use Tails::Persistence::Step::Delete;

use Locale::gettext;
use POSIX;
setlocale(LC_MESSAGES, "");
textdomain("tails-persistence-setup");


=head1 ATTRIBUTES

=cut

has 'verbose' =>
    ro Bool,
    documentation => q{Get more output.},
    default       => sub {
        exists $ENV{DEBUG} && defined $ENV{DEBUG} && $ENV{DEBUG}
    };

has 'force' =>
    lazy_build ro Bool,
    documentation => q{Make some sanity checks non-fatal.};

has 'gui' =>
    lazy_build rw Bool,
    documentation => q{Use the graphical user interface. Set --no-gui to negate.};

has 'dbus' =>
    lazy_build ro 'Net::DBus',
    metaclass => 'NoGetopt';

has 'udisks_service' =>
    lazy_build ro 'Net::DBus::RemoteService',
    metaclass  => 'NoGetopt';

has 'udisks_object' =>
    lazy_build ro 'Net::DBus::RemoteObject',
    metaclass  => 'NoGetopt';

has 'liveos_mountpoint' => (
    isa        => 'Path::Class::Dir',
    is         => 'rw',
    lazy_build => 1,
    coerce     => 1,
    documentation => q{Mountpoint of the Tails system image.},
);

has 'device' =>
    lazy_build rw Str,
    documentation => q{The UDI of the physical block device where Tails is installed, e.g. /org/freedesktop/UDisks/devices/sdb.};

has 'system_partition' =>
    lazy_build rw Str,
    documentation => q{The UDI of the partition where Tails is installed, e.g. /org/freedesktop/UDisks/devices/sdb1.};

has 'main_window' =>
    lazy_build ro 'Gtk2::Window',
    metaclass  => 'NoGetopt';

has 'system_partition_label'         => lazy_build ro Str, metaclass => 'NoGetopt';
has 'system_partition_number'        => lazy_build ro Int, metaclass => 'NoGetopt';
has 'system_partition_attributes'    => lazy_build ro 'ArrayRef[Int]', metaclass => 'NoGetopt';
has 'persistence_partition_label'    => lazy_build ro Str, metaclass => 'NoGetopt';
has 'persistence_partition_guid'     => lazy_build ro Str, metaclass => 'NoGetopt';
has 'persistence_filesystem_type'    => lazy_build ro Str, metaclass => 'NoGetopt';
has 'persistence_filesystem_label'   => lazy_build ro Str, metaclass => 'NoGetopt';
has 'persistence_minimum_size'       => lazy_build ro Int, metaclass => 'NoGetopt';
has 'persistence_partition_size'     => lazy_build ro Int, metaclass => 'NoGetopt';
has 'persistence_filesystem_options' =>
    lazy_build ro 'ArrayRef[Str]',
    metaclass  => 'NoGetopt';
has 'persistence_is_enabled'         => lazy_build ro Bool, metaclass => 'NoGetopt';
has 'persistence_is_read_write'      => lazy_build ro Bool, metaclass => 'NoGetopt';
has 'persistence_partition_mountpoint' => (
    isa        => 'Path::Class::Dir',
    is         => 'rw',
    lazy_build => 1,
    coerce     => 1,
    metaclass  => 'NoGetopt',
);
has 'persistence_state_file'         => (
    isa        => 'Path::Class::File',
    is         => 'ro',
    lazy_build => 1,
    coerce     => 1,
    documentation => q{File where tails-greeter writes persistence state.},
);

foreach (qw{beginning_of_free_space size_of_free_space}) {
    has $_ => lazy_build ro Int, metaclass  => 'NoGetopt';
}

has 'current_step' =>
    rw Object,
    predicate 'has_current_step',
    metaclass  => 'NoGetopt';

has 'steps' =>
    lazy_build required ro 'ArrayRef[Str]',
    traits  => ['Array'],
    handles => {
        all_steps       => 'elements',
        number_of_steps => 'count',
        append_to_steps => 'push',
        shift_steps     => 'shift',
        next_step       => 'first',
        grep_steps      => 'grep',
    },
    documentation => q{Specify once per wizard step to run. Supported steps are: bootstrap, configure, reboot, delete.};

has 'orig_steps' =>
    rw 'ArrayRef[Str]',
    traits  => ['Array'],
    handles => {
        grep_orig_steps => 'grep',
    };

foreach (qw{device_vendor device_model}) {
    has $_ => lazy_build ro Str, metaclass => 'NoGetopt';
}

has 'passphrase' => rw Str, documentation => q{Unsupported. Developers only.};

has 'configuration' =>
    lazy_build rw 'Tails::Persistence::Configuration',
    handles    => { save_configuration => 'save' },
    metaclass  => 'NoGetopt';

has '+codeset'  => ( metaclass => 'NoGetopt' );
has '+encoding' => ( metaclass => 'NoGetopt' );


=head1 CONSTRUCTORS AND BUILDERS

=cut

method BUILD {
    my @orig_steps = $self->all_steps;
    $self->orig_steps(\@orig_steps);
}

sub _build_force {
    my $self = shift;
    0;
}

sub _build_gui { my $self = shift; 1 }

sub _build_persistence_is_enabled {
    my $self = shift;

    -e $self->persistence_state_file || return 0;
    -r $self->persistence_state_file || return 0;

    my $value = $self->get_variable_from_persistence_state_file(
        'TAILS_PERSISTENCE_ENABLED'
    );
    defined($value) && $value eq 'true';
}

sub _build_persistence_is_read_write {
    my $self = shift;

    -e $self->persistence_state_file || return 0;
    -r $self->persistence_state_file || return 0;

    my $value = $self->get_variable_from_persistence_state_file(
        'TAILS_PERSISTENCE_READONLY'
    );
    ! (defined($value) && $value eq 'true');
}

sub _build_steps {
    my $self = shift;

    if ($self->device_has_persistent_volume && $self->persistence_is_enabled) {
        return [ qw{configure reboot} ];
    }

    # TODO: return (bootstrap, configure, reboot), once reboot is implemented.
    return [ qw{bootstrap configure} ];
}

sub _build_dbus {
    my $self = shift;
    Net::DBus::GLib->system;
}

sub _build_udisks_service {
    my $self    = shift;
    $self->dbus->get_service("org.freedesktop.UDisks");
}

sub _build_udisks_object {
    my $self    = shift;
    $self->udisks_service
        ->get_object(
            "/org/freedesktop/UDisks",
            "org.freedesktop.UDisks"
    );
}

sub _build_liveos_mountpoint {
    my $self = shift;
    dir('/live/image');
}

sub _build_device {
    my $self = shift;
    $self->underlying_physical_device($self->liveos_mountpoint);
}

sub _build_system_partition {
    my $self = shift;

    $self->device_partition_with_label(
        $self->device,
        $self->system_partition_label
    );
}

sub _build_system_partition_number {
    my $self = shift;

    my $partition = $self->get_device_property($self->system_partition, 'DeviceFile');
    if (my ($device, $number) = ($partition =~ m{ \A (/dev/sd[a-z]+) ([[:digit:]]+) \z }xms)) {
        return $number;
    }
    else {
        $self->display_error($self->encoding->decode(gettext(
            q{'Unparseable partition path.'},
        )));
    }
}

sub _build_system_partition_attributes {
    my $self = shift;

    [ 2, 60, 62, 63 ];
}

sub _build_main_window {
    my $self = shift;
    my $win = Gtk2::Window->new('toplevel');
    $win->set_title($self->encoding->decode(gettext('Setup Tails persistent storage')));

    $win->set_border_width(10);

    $win->add($self->current_step->main_box) if $self->has_current_step;
    $win->signal_connect('destroy' => sub { Gtk2->main_quit; });
    $win->signal_connect('key-press-event' => sub {
        my $twin = shift;
        my $event = shift;
        $win->destroy if $event->keyval == $Gtk2::Gdk::Keysyms{Escape};
    });
    $win->set_default($self->current_step->go_button) if $self->has_current_step;

    return $win;
}

sub _build_system_partition_label      { my $self = shift; 'Tails'      }
sub _build_persistence_partition_label { my $self = shift; 'TailsData'  }
sub _build_persistence_minimum_size    { my $self = shift; 64 * 2 ** 20 }
sub _build_persistence_filesystem_type { my $self = shift; 'ext3'       }
sub _build_persistence_filesystem_label { my $self = shift; 'TailsData'  }

sub _build_persistence_filesystem_options {
    my $self = shift;

    [
        sprintf("take_ownership_uid=%i", $UID),
        sprintf("take_ownership_gid=%i", getgid()),
        sprintf("label=%s", $self->persistence_filesystem_label),
    ];
}

sub _build_persistence_partition_guid  {
    my $self = shift;
    '8DA63339-0007-60C0-C436-083AC8230908' # Linux reserved
}

sub _build_persistence_partition_mountpoint {
    my $self = shift;

    my $luks = $self->persistence_partition;
    my $luks_holder = $self->get_device_property($luks, 'LuksHolder');
    my $mountpoints = $self->get_device_property($luks_holder, 'DeviceMountPaths');
    return $mountpoints->[0];
}

sub _build_beginning_of_free_space {
    my $self = shift;

    align_up_at_2MiB(
        max(
            map {
                $self->get_device_property($_, 'PartitionOffset')
              + $self->get_device_property($_, 'PartitionSize')
            } $self->partitions
        )
    );
}

sub _build_size_of_free_space {
    my $self = shift;

    align_down_at_2MiB(
        $self->get_device_property($self->device, 'DeviceSize')
      - $self->beginning_of_free_space
  );
}

sub _build_device_vendor {
    my $self = shift;

    $self->get_device_property($self->device, 'DriveVendor');
}

sub _build_device_model {
    my $self = shift;

    $self->get_device_property($self->device, 'DriveModel');
}

sub _build_persistence_partition_size {
    my $self = shift;

    $self->get_device_property($self->persistence_partition, 'PartitionSize');
}

sub _build_configuration {
    my $self = shift;

    Tails::Persistence::Configuration->new(
        config_file_path => file($self->persistence_partition_mountpoint, 'live.persist')
    );
}

method _build_persistence_state_file { '/var/lib/live/config/tails.persistence' }


=head1 METHODS

=cut

sub debug {
    my $self = shift;
    my $mesg = shift;
    say STDERR $self->encoding->encode($mesg) if $self->verbose;
}

sub fatal {
    my $self      = shift;
    my $mesg      = shift;
    my $exit_code = shift;
    $exit_code  ||= 1;
    say STDERR $self->encoding->encode($mesg);
    exit($exit_code);
}

sub display_error {
    my $self  = shift;
    my $title = shift;
    my $mesg   = shift;

    if ($self->gui) {
        my $dialog = Gtk2::MessageDialog->new(
            $self->main_window, 'destroy-with-parent', 'error', 'ok',
            $title
        );
        $dialog->format_secondary_text($mesg);
        $dialog->set_position('center');
        $dialog->run;
    }

    $self->fatal($title . ": " . $mesg);
}

# TODO: move checks to setup steps?
sub check_sanity {
    my $self      = shift;
    my $step_name = shift;

    my %step_checks = (
        'bootstrap' => [
            {
                method  => 'device_has_persistent_volume',
                message => $self->encoding->decode(gettext(
                    "Device %s already has a persistent volume.")),
                must_be_false    => 1,
                can_be_forced    => 1,
                needs_device_arg => 1,
            },
            {
                method  => 'device_has_enough_free_space',
                message => $self->encoding->decode(gettext(
                    "Device %s has not enough unallocated space.")),
                needs_device_arg => 1,
            },
        ],
        'delete' => [
            {
                method  => 'device_has_persistent_volume',
                message => $self->encoding->decode(gettext(
                    "Device %s has no persistent volume.")),
                needs_device_arg => 1,
            },
            {
                method  => 'persistence_is_enabled',
                message => $self->encoding->decode(gettext(
                    "Persistent volume is in use: persistence is enabled.")),
                must_be_false => 1,
            },
        ],
        'configure' => [
            {
                method  => 'device_has_persistent_volume',
                message => $self->encoding->decode(gettext(
                    "Device %s has no persistent volume.")),
                needs_device_arg => 1,
            },
        ],
    );

    if (! $self->grep_orig_steps(sub { $_ eq 'bootstrap' })) {
        push @{$step_checks{configure}}, (
            {
                method  => 'persistence_is_enabled',
                message => $self->encoding->decode(gettext(
                    "Persistence is not enabled.")),
                can_be_forced => 1,
            },
            {
                method  => 'persistence_is_read_write',
                message => $self->encoding->decode(gettext(
                    "Writing is not enabled for persistence.")),
                can_be_forced => 1,
            },
        );
    }

    my @checks = (
        {
            method  => 'device_is_usb',
            message => $self->encoding->decode(gettext(
                "Tails is running from non-USB device %s.")),
            needs_device_arg => 1,
        },
        {
            method  => 'device_is_optical',
            message => $self->encoding->decode(gettext(
                "Device %s is optical.")),
            must_be_false    => 1,
            needs_device_arg => 1,
        },
        {
            method  => 'device_has_tails',
            message => $self->encoding->decode(gettext(
                "Device %s was not created using Tails USB creator.")),
            must_be_false    => 0,
            needs_device_arg => 1,
        },
    );
    push @checks, @{$step_checks{$step_name}} if $step_name;

    foreach my $check (@checks) {
        my $check_method = $self->meta->get_method($check->{method});
        my $res;
        if (exists($check->{needs_device_arg}) && $check->{needs_device_arg}) {
            $res = $check_method->execute($self, $self->device);
        }
        else {
            $res = $check_method->execute($self);
        }
        if (exists($check->{must_be_false}) && $check->{must_be_false}) {
            $res = ! $res;
        }
        if (! $res) {
            my $message = $self->encoding->decode(sprintf(
                gettext($check->{message}),
                $self->device));
            if ($self->force && exists($check->{can_be_forced}) && $check->{can_be_forced}) {
                warn "$message",
                     "... but --force is enabled, ignoring results of this sanity check.";
            }
            else {
                $self->display_error(
                    $self->encoding->decode(gettext('Error')),
                    $message
                );
                return;
            }
        }
    }

    return 1;
}

sub run {
    my $self = shift;

    $self->debug(sprintf("Working on device %s", $self->device));

    if ($self->gui) {
        $self->main_window->set_visible(FALSE);
        $self->goto_next_step;
        $self->debug("Entering main Gtk2 loop.");
        Gtk2->main;
    }
    else {
        my $next_step = $self->shift_steps;
        if ($next_step && $self->check_sanity($next_step)) {
            $self->current_step($self->step_object_from_name($next_step));
            $self->current_step->go_callback->(async => 0);
        }
    }
}

sub get_device_property {
    my $self     = shift;
    my $device   = shift;
    my $property = shift;

    $self->udisks_service
        ->get_object($device)
        ->as_interface("org.freedesktop.DBus.Properties")
        ->Get('org.freedesktop.DBus.Properties', $property);
}

sub device_is_usb {
    my $self   = shift;
    my $device = shift;

    'usb' eq $self->get_device_property($device, 'DriveConnectionInterface');
}

sub device_is_optical {
    my $self   = shift;
    my $device = shift;

    $self->get_device_property($device, 'DeviceIsOpticalDisc');
}

sub device_partition_with_label {
    my $self   = shift;
    my $device = shift;
    my $label  = shift;

    first {
        $label eq $self->get_device_property($_, 'PartitionLabel')
    } $self->partitions($device)
}

sub device_has_partition_with_label {
    my $self   = shift;
    my $device = shift;
    my $label  = shift;

    defined $self->device_partition_with_label($device, $label);
}

sub device_has_tails {
    my $self   = shift;
    my $device = shift;

    'gpt' eq $self->get_device_property($device, 'PartitionTableScheme')
        or return;

    $self->device_has_partition_with_label($device, $self->system_partition_label)
        or return;

    return 1;
}

sub device_has_persistent_volume {
    my $self   = shift;
    my $device = shift;

    return $self->device_has_partition_with_label($device, $self->persistence_partition_label);
}

sub device_has_enough_free_space {
    my $self   = shift;
    my $device = shift;

    $self->size_of_free_space >= $self->persistence_minimum_size;
}

sub persistence_partition {
    my $self = shift;

    $self->device_partition_with_label(
        $self->device,
        $self->persistence_partition_label
    );
}

sub partitions {
    my $self   = shift;
    my $device = shift;
    $device  ||= $self->device;

    grep {
        $_ =~ m{\A $device [0-9]+ \z}xms
    } @{$self->udisks_object->EnumerateDevices()};
}

sub create_persistence_partition {
    my $self = shift;
    (my $opts = shift) ||= {};
    $opts->{async}     ||= 0;
    $opts->{end_cb}    ||= sub { say STDERR "finished." };
    my $passphrase = $self->gui ? $opts->{passphrase} : $self->passphrase;

    my $offset    = $self->beginning_of_free_space;
    my $size      = $self->size_of_free_space;
    my $type      = $self->persistence_partition_guid;
    my $label     = $self->persistence_partition_label;
    my $flags     = [];
    my $options   = [];
    my $fstype    = $self->persistence_filesystem_type;
    my $fsoptions = [
        @{$self->persistence_filesystem_options},
        sprintf('luks_encrypt=%s', $passphrase)
    ];

    my $obj = $self->udisks_service->get_object($self->device);

    $self->debug(sprintf(
        "Creating partition of size %s at offset %s on device %s",
        format_bytes($size, mode => "iec"), $offset, $self->device
    ));

    if ($opts->{async}) {
        # Net::DBus::RemoteObject's _call_method hardcodes a 60 seconds timeout.
        # Unfortunately, mkfs operations on relatively big USB devices often
        # need more time than this. Therefore, we have to dive into lower level
        # private API's to build a ::PendingCall object with a suitable timeout.
        my $connexion = $self->dbus->get_connection;
        my $timeout = 240 * 1000;
        my $method_call = $connexion->make_method_call_message(
            $self->udisks_service->get_service_name(),
            $self->device,
            "org.freedesktop.UDisks.Device",
            "PartitionCreate"
        );
        $method_call->append_args_list(
            dbus_uint64($offset),
            dbus_uint64($size),
            $type, $label, $flags, $options, $fstype, $fsoptions
        );
        my $pending_call = $connexion->send_with_reply($method_call, $timeout);
        my $reply = Net::DBus::ASyncReply->_new(pending_call => $pending_call);
        $reply->set_notify($opts->{end_cb});
        $self->debug("waiting...");
    }
    else {
        $obj->as_interface("org.freedesktop.UDisks.Device")
            ->PartitionCreate(
                $offset, $size, $type, $label, $flags, $options,
                $fstype, $fsoptions
            );
        $self->debug("done.");
    }
}

sub delete_persistence_partition {
    my $self = shift;
    (my $opts = shift) ||= {};
    $opts->{async}     ||= 0;
    $opts->{end_cb}    ||= sub { say STDERR "finished." };

    $self->debug(sprintf("Deleting partition %s", $self->persistence_partition));

    # lock the device if it is unlocked (a locked device's LuksHolder is '/')
    my $luksholder = $self->get_device_property(
        $self->persistence_partition, 'LuksHolder'
    );
    if ('/' ne $luksholder) {
        if ($self->get_device_property($luksholder, 'DeviceIsMounted')) {
            $self->udisks_service
                ->get_object($luksholder)
                ->as_interface("org.freedesktop.UDisks.Device")
                ->FilesystemUnmount([])
        }
        $self->udisks_service
            ->get_object($self->persistence_partition)
            ->as_interface("org.freedesktop.UDisks.Device")
            ->LuksLock([])
    }

    # TODO: wipe the LUKS header

    if ($opts->{async}) {
        $self->udisks_service
            ->get_object($self->persistence_partition)
            ->as_interface("org.freedesktop.UDisks.Device")
            ->PartitionDelete(dbus_call_async, [])
            ->set_notify($opts->{end_cb});
        $self->debug("waiting...");
    }
    else {
        $self->udisks_service
            ->get_object($self->persistence_partition)
            ->as_interface("org.freedesktop.UDisks.Device")
            ->PartitionDelete([]);
        $self->debug("done.");
    }
}

sub mount_persistence_partition {
    my $self = shift;
    (my $opts = shift) ||= {};
    $opts->{async}     ||= 0;
    $opts->{end_cb}    ||= sub { say STDERR "finished." };

    $self->debug(sprintf("Mounting partition %s", $self->persistence_partition));

    my $luks_holder = $self->get_device_property(
        $self->persistence_partition, 'LuksHolder');

    if ($opts->{async}) {
        $self->udisks_service
            ->get_object($luks_holder)
            ->as_interface("org.freedesktop.UDisks.Device")
            ->FilesystemMount(dbus_call_async,
                              $self->persistence_filesystem_type, [])
            ->set_notify($opts->{end_cb});
        $self->debug("waiting...");
    }
    else {
        my $mountpoint = $self->udisks_service
            ->get_object($luks_holder)
            ->as_interface("org.freedesktop.UDisks.Device")
            ->FilesystemMount($self->persistence_filesystem_type, []);
        $self->debug("done.");
        return $mountpoint;
    }
}


=head2 underlying_physical_device

Returns the physical block device UDI (e.g.
/org/freedesktop/UDisks/devices/sdb) on which the specified file
is stored.

=cut
sub underlying_physical_device {
    my $self = shift;
    my $path = shift;

    my $st     = stat($path);
    my $device = $self->udisks_object->FindDeviceByMajorMinor(major($st->dev), minor($st->dev));
    my $parent = $self->get_device_property($device, 'PartitionSlave');
    if ($parent and $parent ne '/') {
        return $parent;
    }
    else {
        return $device;
    }
}

sub empty_main_window {
    my $self = shift;

    my $child = $self->main_window->get_child;
    $self->main_window->remove($child) if defined($child);
}

sub run_current_step {
    my $self = shift;

    $self->debug("Running step " . $self->current_step->name);

    $self->current_step->working(0);
    $self->empty_main_window;
    $self->main_window->add($self->current_step->main_box);
    $self->main_window->set_default($self->current_step->go_button);
    $self->main_window->show_all;
    $self->current_step->working(0);
    $self->main_window->set_visible(TRUE);
}

sub goto_next_step {
    my $self = shift;
    (my $opts = shift) ||= {};

    my $next_step;

    if ($next_step = $self->shift_steps) {
        if ($self->check_sanity($next_step)) {
            $self->current_step($self->step_object_from_name($next_step));
            $self->run_current_step;
        }
    }
    else {
        $self->debug("No more steps.");
        $self->current_step->title->set_text($self->encoding->decode(gettext(
            q{Persistence wizard - Finished}
        )));
        $self->current_step->subtitle->set_text($self->encoding->decode(gettext(
            q{You may now close this application.}
        )));
        $self->current_step->description->set_text(' ');
        $self->current_step->go_button->hide;
        $self->current_step->status_area->hide;
    }
}

sub step_object_from_name {
    my $self = shift;
    my $name = shift;

    my $class_name = step_name_to_class_name($name);

    my %init_args;

    if ($name eq 'bootstrap') {
        %init_args = (
            go_callback => sub {
                $self->create_persistence_partition({ @_ })
            },
            size_of_free_space          => $self->size_of_free_space,
            should_mount_persistence_partition =>
                0 < $self->grep_steps(sub { $_ eq 'configure' }),
            mount_persistence_partition_cb => sub {
                $self->mount_persistence_partition({ @_ })
            },
        );
    }
    elsif ($name eq 'delete') {
        %init_args = (
            go_callback => sub {
                $self->delete_persistence_partition({ @_ })
            },
            persistence_partition      => $self->persistence_partition,
            persistence_partition_size => $self->persistence_partition_size,
        );
    }
    elsif ($name eq 'configure') {
        %init_args = (
            go_callback => sub {
                $self->save_configuration({ @_ })
            },
            configuration              => $self->configuration,
            persistence_partition      => $self->persistence_partition,
            persistence_partition_size => $self->persistence_partition_size,
        );
    }

    return $class_name->new(
        name             => $name,
        encoding         => $self->encoding,
        success_callback => sub { $self->goto_next_step({ @_ }) },
        fix_attributes_callback => sub { $self->fix_system_partition_attributes(@_) },
        device_vendor    => $self->device_vendor,
        device_model     => $self->device_model,
        %init_args
    );

}

sub fix_system_partition_attributes {
    my $self = shift;

    system(
        '/sbin/sgdisk',
        $self->get_device_property($self->device, 'DeviceFile'),
        map {
            sprintf('--attributes=%d:set:%d', $self->system_partition_number, $_)
        } @{$self->system_partition_attributes}
    );
}

method get_variable_from_persistence_state_file (Str $variable) {
    get_variable_from_file($self->persistence_state_file, $variable);
}

no Moose;
1;
