=head1 NAME

Tails::Persistence::Role::HasEncoding - role to provide an Encode::Encoding objet for the codeset being used

=head1 SYNOPSIS

    use MooseX::Declare;
    class Tails::Persistence::Daemon with Tails::Persistence::Role::HasEncoding {
        method foo (Str $bytes) { $self->encoding-> }
    }

    See Tails::Persistence::Daemon for a real-life usage example.

=cut

package Tails::Persistence::Role::HasEncoding;
use Moose::Role;

our $VERSION = '0.14'; # VERSION

use namespace::autoclean;
with 'Tails::Persistence::Role::HasCodeset';
use Encode qw{find_encoding};
use Moose::Util::TypeConstraints;

class_type('Encode::Encoding');
class_type('Encode::XS');

has 'encoding' => (
    isa        => 'Encode::Encoding | Encode::XS',
    is         => 'ro',
    lazy_build => 1,
);

sub _build_encoding {
    my $self = shift;
    find_encoding($self->codeset);
}

no Moose::Role;
1; # End of Tails::Persistence::Role::HasEncoding
