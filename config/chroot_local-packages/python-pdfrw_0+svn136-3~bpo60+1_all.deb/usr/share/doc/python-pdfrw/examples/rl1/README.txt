This directory contains example scripts which read in PDFs
and convert pages to PDF Form XObjects using pdfrw, and then
write out the PDFs using reportlab.

The examples, from easiest to hardest, are:

subset.py -- prints a subset of pages
4up.py -- prints pages 4-up
booklet.py -- creates a booklet out of the pages
