The copy.py demo in this directory parses the graphics stream from the PDF and actually plays it back through reportlab.

Doesn't yet handle fonts or unicode very well.

For a more practical demo, look at the Form XObjects approach in the examples/rl1 directory.
