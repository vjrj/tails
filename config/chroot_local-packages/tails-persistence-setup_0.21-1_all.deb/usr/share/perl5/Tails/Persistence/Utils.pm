=head1 NAME

Tails::Persistence::Utils - utilities for Tails persistent storage

=cut

package Tails::Persistence::Utils;

use strict;
use warnings FATAL => 'all';
use 5.10.1;

our $VERSION = '0.21'; # VERSION

use Exporter;
our @ISA = qw{Exporter};
our @EXPORT = qw{align_up_at_2MiB align_down_at_2MiB step_name_to_class_name get_variable_from_file};

use List::MoreUtils qw{last_value};
use Path::Class;


=head1 FUNCTIONS

=cut

sub round_down {
    my $number = shift;
    my $round = shift;

    return (int($number/$round)) * $round if $number % $round;
    return $number;
}

sub round_up {
    my $number = shift;
    my $round = shift;

    return (1 + int($number/$round)) * $round if $number % $round;
    return $number;
}

sub align_up_at_2MiB {
    my $bytes = shift;

    round_up($bytes, 2 * 2 ** 20)
}

sub align_down_at_2MiB {
    my $bytes = shift;

    round_down($bytes, 2 * 2 ** 20)
}

sub step_name_to_class_name {
    my $name = shift;

    'Tails::Persistence::Step::' . ucfirst($name);
}

sub get_variable_from_file {
    my $file     = shift;
    my $variable = shift;

    foreach my $line (file($file)->slurp(chomp => 1)) {
        if (my ($name, $value) =
                ($line =~ m{\A [[:space:]]* ($variable)=(.*) \z}xms)) {
            return $value;
        }
    }

    return;
}

1;
