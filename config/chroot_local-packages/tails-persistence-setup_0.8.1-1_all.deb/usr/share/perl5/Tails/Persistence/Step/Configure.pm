=head1 NAME

Tails::Persistence::Step::Configure - configure which bits are persistent

=cut

package Tails::Persistence::Step::Configure;
use Moose;
use MooseX::Method::Signatures;
use MooseX::Types::Moose qw( :all );
use MooseX::Has::Sugar::Saccharin;

our $VERSION = '0.8.1'; # VERSION

use Glib qw{TRUE FALSE};

use Number::Format qw(:subs);
use Tails::Persistence::Configuration::Button;
use Try::Tiny;

use Locale::gettext;
use POSIX;
setlocale(LC_MESSAGES, "");
textdomain("tails-persistence-setup");


=head1 ATTRIBUTES

=cut

has 'configuration' => required ro 'Tails::Persistence::Configuration';

has 'persistence_partition'      => required ro Str;
has 'persistence_partition_size' => required ro Int;

has 'list_box' => ro 'Gtk2::VBox', builder '_build_list_box';

has 'buttons'  =>
    lazy_build ro 'ArrayRef[Tails::Persistence::Configuration::Button]',
    traits  => [ 'Array' ],
    handles => {
        all_buttons => 'elements',
        push_button => 'push',
    };

has 'add_area'              => lazy_build ro 'Gtk2::HBox';
has 'add_source_label'      => lazy_build ro 'Gtk2::Label';
has 'add_source_entry'      => lazy_build ro 'Gtk2::Entry';
has 'add_destination_label' => lazy_build ro 'Gtk2::Label';
has 'add_destination_entry' => lazy_build ro 'Gtk2::Entry';
has 'add_button'            => lazy_build ro 'Gtk2::Button';


=head1 CONSTRUCTORS

=cut

sub BUILD {
    my $self = shift;

    $self->title->set_text($self->encoding->decode(gettext(
        q{Persistence wizard - Configuration}
    )));
    $self->subtitle->set_text($self->encoding->decode(gettext(
        q{Decide which files should persist}
    )));
    # TRANSLATORS: partition, size, device vendor, device model
    $self->description->set_markup($self->encoding->decode(sprintf(
        gettext(q{The selected files will be stored on the Tails persistence partition %s (%s), on the <b>%s %s</b> device.}),
        $self->persistence_partition,
        format_bytes($self->persistence_partition_size, mode => "iec"),
        $self->device_vendor,
        $self->device_model
    )));
    $self->go_button->set_label($self->encoding->decode(gettext(q{Save})));
    $self->go_button->set_sensitive(TRUE);
}

method _build_main_box {
    my $box = Gtk2::VBox->new();
    $box->set_spacing(6);
    $box->pack_start($self->title, FALSE, FALSE, 0);
    $box->pack_start($self->subtitle, FALSE, FALSE, 0);
    $box->pack_start($self->description, FALSE, FALSE, 0);

    my $viewport = Gtk2::Viewport->new;
    $viewport->set_shadow_type('GTK_SHADOW_NONE');
    $viewport->add($self->list_box);
    my $scrolled_win = Gtk2::ScrolledWindow->new;
    $scrolled_win->set_policy('automatic', 'automatic');
    $scrolled_win->add($viewport);
    $box->pack_start($scrolled_win, TRUE, TRUE, 0);

    $box->pack_start($self->add_area, FALSE, FALSE, 0);

    $box->pack_start($self->status_area, FALSE, FALSE, 0);

    my $button_alignment = Gtk2::Alignment->new(1.0, 0, 0.2, 1.0);
    $button_alignment->set_padding(0, 0, 10, 10);
    $button_alignment->add($self->go_button);
    $box->pack_start($button_alignment, FALSE, FALSE, 0);

    return $box;
}

method _build_buttons {
    [
        map {
            Tails::Persistence::Configuration::Button->new(atom => $_)
        } $self->configuration->all_atoms
    ]
}

method _build_list_box {
    my $box = Gtk2::VBox->new();
    $box->set_spacing(6);
    $box->pack_start($_->main_widget, FALSE, FALSE, 0) foreach $self->all_buttons;
    $self->refresh_buttons;

    return $box;
}

method _build_add_area {
    my $box = Gtk2::HBox->new();
    $box->pack_start($_, FALSE, FALSE, 0)
        for (
            $self->add_source_label,
            $self->add_source_entry,
            $self->add_destination_label,
            $self->add_destination_entry,
            $self->add_button
        );

    return $box;
}

method _build_add_source_label {
    Gtk2::Label->new($self->encoding->decode(gettext(
        q{Source:}
    )));
}

method _build_add_destination_label {
    Gtk2::Label->new($self->encoding->decode(gettext(
        q{Destination:}
    )));
}

method _build_add_source_entry      {
    my $entry = Gtk2::Entry->new;
    $entry->signal_connect('changed' => sub {
        if ($entry->get_text_length) {
            $self->add_button->set_sensitive(TRUE)
        }
        else {
            $self->add_button->set_sensitive(FALSE)
        }
    });

    return $entry;
}

method _build_add_destination_entry { Gtk2::Entry->new }

method _build_add_button {
    my $button = Gtk2::Button->new_from_stock('gtk-add');
    $button->set_sensitive(FALSE);
    $button->signal_connect('clicked' => sub {
        my $atom = Tails::Persistence::Configuration::Atom->new(
            source      => $self->add_source_entry->get_text,
            destination => $self->add_destination_entry->get_text,
            enabled     => 1
        );
        $self->configuration->push_atom($atom);
        my $button = Tails::Persistence::Configuration::Button->new(
            atom => $atom
        );
        $self->push_button($button);
        $self->list_box->pack_start($button->main_widget, FALSE, FALSE, 0);
        $button->main_widget->show_all;
        $self->add_source_entry->set_text('');
        $self->add_destination_entry->set_text('');
        $self->add_button->set_sensitive(FALSE);
    });
    return $button;
}


=head1 METHODS

=cut

method operation_finished ($error) {
    if ($error) {
        $self->working(0);
        say STDERR "$error";
        $self->subtitle->set_text($self->encoding->decode(gettext(q{Failed})));
        $self->description->set_text($error);
    }
    else {
        say STDERR "done.";
        $self->working(0);
        $self->success_callback->();
    }
}

method go_button_pressed {
    $self->list_box->hide;
    $self->add_area->hide;
    $self->working(1);
    $self->subtitle->set_text(
        $self->encoding->decode(gettext(q{Saving...})),
    );
    $self->description->set_text(
        $self->encoding->decode(gettext(q{Saving persistence configuration...})),
    );

    my $error;
    try {
        $self->go_callback->();
    } catch {
        $error = $@;
    };
    $self->operation_finished($error);
}

method refresh_buttons {
    $_->refresh_display foreach $self->all_buttons;
}

with 'Tails::Persistence::Role::StatusArea';
with 'Tails::Persistence::Role::SetupStep';

no Moose;
1;
