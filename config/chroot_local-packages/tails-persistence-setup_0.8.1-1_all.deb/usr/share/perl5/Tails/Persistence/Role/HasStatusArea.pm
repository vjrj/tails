=head1 NAME

Tails::Persistence::Role::HasStatusArea - status area interface

=cut

package Tails::Persistence::Role::HasStatusArea;
use Moose::Role;

our $VERSION = '0.8.1'; # VERSION

requires 'status_area';
requires 'working';

no Moose 'Role';
1;
