<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/1998/REC-html40-19980424/loose.dtd">
<html>
<head>
  <title>Tor: Instrukcje instalacji dla Mac OS X</title>
  <meta name="Author" content="Roger Dingledine">
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" type="text/css" href="../stylesheet-ltr.css">
  <link rel="shortcut icon" type="image/x-icon" href="../favicon.ico">
</head>
<body>
<div class="center">
<table class="banner" border="0" cellpadding="0" cellspacing="0" summary="">
    <tr>
        <td class="banner-left"><a href="https://www.torproject.org/"><img src="../images/top-left.png" alt="Click to go to home page" width="193" height="79"></a></td>
        <td class="banner-middle">
	<a href="../index.html.pl">Strona główna</a>
<a href="../overview.html.pl">Wprowadzenie</a>
<a href="../easy-download.html.pl">Pobieranie plików</a>
<a href="../documentation.html.pl">Dokumentacja</a>
<a href="../volunteer.html.pl">Wolontariusze</a>
<a href="../people.html.pl">Ludzie</a>
<a href="https://blog.torproject.org/">Blog</a>
<a href="../donate.html.pl">Dotacje</a>
        </td>
        <td class="banner-right">
	<a href="tor-doc-osx.html.de"><acronym title="Deutsch"><img src="../images/de.png" alt="Deutsch" width="24" height="16"></acronym></a> <a href="tor-doc-osx.html.en"><acronym title="English"><img src="../images/en.png" alt="English" width="24" height="16"></acronym></a> <a href="tor-doc-osx.html.es"><acronym title="espa&ntilde;ol"><img src="../images/es.png" alt="espa&ntilde;ol" width="24" height="16"></acronym></a> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <a href="tor-doc-osx.html.fr"><acronym title="fran&ccedil;ais"><img src="../images/fr.png" alt="fran&ccedil;ais" width="24" height="16"></acronym></a> <a href="tor-doc-osx.html.it"><acronym title="Italiano"><img src="../images/it.png" alt="Italiano" width="24" height="16"></acronym></a> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <a href="tor-doc-osx.html.ko"><acronym title="&#54620;&#44397;&#50612;&nbsp;(Hangul)"><img src="../images/ko.png" alt="&#54620;&#44397;&#50612;&nbsp;(Hangul)" width="24" height="16"></acronym></a> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <acronym title="polski"><img src="../images/pl.png" alt="polski" width="24" height="16"></acronym> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <a href="tor-doc-osx.html.zh-cn"><acronym title="&#20013;&#25991;(&#31616;) (Simplified Chinese)"><img src="../images/zh-cn.png" alt="&#20013;&#25991;(&#31616;) (Simplified Chinese)" width="24" height="16"></acronym></a>
        </td>
    </tr>
</table>
<div class="center">
<div class="main-column">
<h1>Uruchamianie klienta <a href="../index.html.pl">Tor</a> na Mac OS X</h1>
<br>
<p>
<b>To są instrukcje do instalacji klienta Tora na systemie Mac OS X. Jeśli chcesz
 przekazywać ruch innych, by wspomóc rozwój sieci (prosimy), przeczytaj poradnik o <a
  href="../docs/tor-doc-relay.html.pl">Konfigurowaniu przekaźnika sieci Tor</a>.</b>
</p>
<hr>
<a id="installing"></a>
<h2><a class="anchor" href="#installing">Krok 1: Pobranie i instalacja Tora</a></h2>
<br>
<p>Wersje instalacyjne dla Macintosh OS X zawierają
 <a href="../index.html.pl">Tora</a>,
 <a href="../vidalia/index.html">Vidalia</a> (graficzny interfejs dla Tora),
 <a href="../torbutton/index.html.pl">Torbutton</a>,
 i <a href="http://www.pps.jussieu.fr/~jch/software/polipo/">Polipo</a> (serwer pośredniczący proxy)
 w jednej paczce, ze wszystkimi czterema programami prekonfigurowanymi do współpracy ze sobą.
 Pobierz albo <a href="../dist/vidalia-bundles/vidalia-bundle-0.2.1.21-0.2.6-i386.dmg">stabilną</a>
 albo <a href="../dist/vidalia-bundles/vidalia-bundle-0.2.2.6-alpha-0.2.6-i386.dmg">eksperymentalną</a> wersję
 paczki dla OS X, lub poszukaj innych rozwiązań na <a href="../download.html.pl">stronie pobierania</a>.
</p>
<p>Po pobraniu dmg, kliknij go dwukrotnie i pozwól, by się zamontował. Przejdź do teraz
otwartej paczki Vidalia (Vidalia Bundle) w Finderze. Paczkę łatwo jest zainstalować; po prostu
przenieś i upuść cebulową ikonę Vidalii do folderu Aplikacji. Opcjonalnie, kliknij dwukrotnie
skrypt "install torbutton", by zainstalować Torbutton do Firefoksa. Możesz też pobrać
Torbuttona ze strony z dodatkami Mozilli, wyszukując "torbutton".</p>
<p>Po zakończeniu instalacji możesz uruchomić program Vidalia poprzez wybranie
 jego ikony z twojego folderu Aplikacji. Ciemna cebula z czerwonym krzyżykiem na
 pasku oznacza, że w tej chwili Tor nie jest uruchomiony. Możesz uruchomić Tora
 wybierając Start z menu "Tor" u góry ekranu.
</p>
<p>Gdy Tor działa, ikonka programu Vidalia wygląda tak:
</p>
<p><img alt="Vidalia z działającym Torem"
src="../img/screenshot-osx-vidalia.png"
border="1" width="223" height="100"></p>
<p>Polipo jest instalowane jako część pakietu Tora. Po jego instalacji,
 uruchomi się automatycznie po restarcie komputera.
 Nie musisz konfigurować Polipo, by używało Tora &mdash; odpowiednia konfiguracja
 Polipo została zainstalowana jako część pakietu instalacyjnego.
</p>
<hr>
<a id="using"></a>
<h2><a class="anchor" href="#using">Krok 2: Konfiguracja aplikacji, by używały Tora</a></h2>
<br>
<p>Po instalacji musisz skonfigurować swoje aplikacje, by ich używały.
 Pierwszym krokiem jest ustawienie sposobu przeglądania sieci WWW.</p>
<p>Powinieneś/aś używać Tora z Firefoksem i Torbuttonem, dla najlepszego bezpieczeństwa.
 Torbutton został zainstalowany za Ciebie. Kliknij na czerwony przycisk "Tor Disabled"
 ("Tor wyłączony"), by włączyć Tora i gotowe:
</p>
<p><img alt="Rozszerzenie Torbutton dla Firefoksa"
src="../img/screenshot-torbutton.png"
border="1" width="161" height="78"></p>
<br>
<p>
 Jeśli masz zamiar używać Firefoksa na innym komputerze niż tam, gdzie jest Tor, spójrz na <a
 href="https://wiki.torproject.org/noreply/TheOnionRouter/TorFAQ#SocksListenAddress">wpis w FAQ
 na temat uruchamiania Tora na innym komputerze</a>.
</p>
<p>By "storyfikować" inne aplikacje, które używają proxy dla HTTP, po prostu
 skieruj je na Polipo (czyli localhost, port 8118). By aplikacje bezpośrednio używały
 serwera SOCKS (do komunikatorów, Jabbera, IRC, itp.), skieruj je
 bezpośrednio na Tora (localhost, port 9050), ale przeczytaj <a
 href="https://wiki.torproject.org/noreply/TheOnionRouter/TorFAQ#SOCKSAndDNS">ten
 wpis do FAQ</a>, dlaczego to może być niebezpieczne. Jeśli aplikacja nie
 obsługuje ani proxy dla HTTP, ani dla SOCKS, spójrz na <a
 href="http://www.taiyo.co.jp/~gotoh/ssh/connect.html">connect</a> lub
 <a href="http://www.dest-unreach.org/socat/">socat</a>.</p>
<p>Po informacje, jak "storyfikować" inne aplikacje, spójrz na
 <a href="https://wiki.torproject.org/noreply/TheOnionRouter/TorifyHOWTO">Torify
 HOWTO</a>.
</p>
<hr>
<a id="verify"></a>
<h2><a class="anchor" href="#verify">Krok 3: Upewnij się, że wszystko działa</a></h2>
<br>
<p>Teraz powinieneś spróbować użyć swojej przeglądarki z Torem i
 upewnić się, że Twój adres IP jest anonimizowany. Kliknij na
 <a href="https://check.torproject.org/">wykrywacz
 Tora</a> i sprawdź, cze jego zdaniem używasz Tora czy nie.
 (Jeśli ta strona akurat nie działa, przeczytaj <a
 href="https://wiki.torproject.org/noreply/TheOnionRouter/TorFAQ#IsMyConnectionPrivate">ten
 wpis w FAQ</a>, by poznać więcej sposobów na testowanie swojego Tora.)
</p>
<p>Jeśli masz zaporę ogniową, która ogranicza możliwości Twojego komputera co
 do łączenia się z samym sobą, zezwól w niej na połączenia od programów
 lokalnych na porty lokalne 8118 i 9050. Jeśli zapora blokuje połączenia
 wychodzące, spraw, by można się było połączyć choć z portami 80 i 433,
 po czym przeczytaj <a
 href="https://wiki.torproject.org/noreply/TheOnionRouter/TorFAQ#FirewalledClient">ten
 wpis do FAQ</a>.
</p>
<p>Jeśli dalej nie działa, spójrz na <a
 href="https://wiki.torproject.org/noreply/TheOnionRouter/TorFAQ#ItDoesntWork">ten
 wpis FAQ</a>, by poszukać wskazówek.</p>
<p>
Gdy Tor już działa, poczytaj o tym,
<a href="../download.html.pl#Warning">co Tor oferuje, a czego nie</a>.
</p>
<hr>
<a id="server"></a>
<a id="relay"></a>
<h2><a class="anchor" href="#relay">Krok 4: Konfiguracja Tora jako przekaźnika sieci</a></h2>
<br>
<p>Sieć Tora polega na ochotnikach oddających część swojego łącza. Im więcej
 ludzi uruchomi przekaxnik sieci, tym szybsza będzie sieć Tora. Jeśli masz co najmniej
 20 kilobajtów/s w obie strony, pomóż Torowi, konfigurując swojego klienta tak,
 by był także przekaźikiem sieci. Mamy wiele cech, które czynią przekaźniki Tora łatwymi i
 wygodnymi, łącznie z ograniczeniem przepustowości, politykami wyjścia, byś mógł
 zmniejszyć ryzyko skarg, oraz obsługą dynamicznych adresów IP.</p>
<p>Posiadanie przekaźników w wielu różnych miejscach w sieci sprawia, że
 użytkownicy są bezpieczni. <a
 href="https://wiki.torproject.org/noreply/TheOnionRouter/TorFAQ#RelayAnonymity">Ty
 też możesz mieć lepszą anonimowość</a>, gdyż serwery, do których się łączysz,
 nie mogą stwierdzić, czy połączenie pochodzi z Twojego komputera, czy
 zostało przekierowane z innych.</p>
<p>Przeczytaj szczegóły w naszym przewodniku <a href="../docs/tor-doc-relay.html.pl">Konfiguracji
przekaźnika sieci Tor</a>.</p>
<hr>
<a id="uninstall"></a>
<h2><a class="anchor" href="#uninstall">Jak odinstalować Tora i Privoxy</a></h2>
<br>
<p>Są dwa sposoby na odinstalowanie paczki z komputera, z wykorzystaniem Findera albo
poprzez program odinstalowujący uruchamiany z linii
 poleceń (Terminala). Jeśli chcesz usunąć Tora z systemu OSX, oto jak to zrobić:</p>
<p>Przywróć ustawienia Proxy w aplikacjach do ich poprzednich wartości. Jeśli chcesz
 tylko przestać używać Tora, możesz przerwać na tym kroku.</p>
<p>Jeśli chcesz całkowicie usunąć Tora, a twoje konto ma prawa
 Administratora, wykonaj co następuje:</p>
<ol>
<li> Otwórz Findera i kliknij Aplikacje.</li>
<li> Przeciągnij /Applications/Vidalia do kosza</li>
<li> Usuń /Library/Torbutton z systemu</li>
<li> W swoim katalogu domowym przejdź do Library, usuń katalog Vidalia</li>
</ol>
<p>Tor, Vidalia i Polipo są teraz całkowicie usunięte z systemu.</p>
<p>Jeśli znasz linię poleceń lub Terminal, możesz ręcznie usunąć następujące elementy:</p>
<ul>
<li>/Applications/Vidalia.app/</li>
<li>/Library/Torbutton/</li>
<li>~/Library/Vidalia</li>
<li>~/.tor</li>
</ul>
<hr>
<p>Jeśli masz pomysły na ulepszenie tej strony, prosimy <a
href="../contact.html.pl">je do nas wysłać</a>. Dziękujemy!</p>
  </div><!-- #main -->
</div>
<hr>
</div>
  <div class="bottom" id="bottom">
     <p>"Tor" i "Onion Logo" (logo cebuli) są <a href="../trademark-faq.html.pl">zarejestrowanymi znakami handlowymi</a> The Tor Project, Inc.<br>
	Zawartość tej strony jest pod licencją
	<a href="http://creativecommons.org/licenses/by/3.0/us/">Creative Commons Attribution
	3.0 United States License</a>, chyba że napisano inaczej.
	</p>
     <p>
       Ta strona jest także dostępna w następujących językach:
       <a href="tor-doc-osx.html.de">Deutsch</a>, <a href="tor-doc-osx.html.en">English</a>, <a href="tor-doc-osx.html.es">espa&ntilde;ol</a>, <a href="tor-doc-osx.html.fr">fran&ccedil;ais</a>, <a href="tor-doc-osx.html.it">Italiano</a>, <a href="tor-doc-osx.html.ko">&#54620;&#44397;&#50612;&nbsp;(Hangul)</a>, <a href="tor-doc-osx.html.zh-cn">&#20013;&#25991;(&#31616;) (Simplified Chinese)</a>.<br>
       Jak ustawić <a href="http://www.debian.org/intro/cn.pl.html#howtoset">domyślny język dokumentu</a>.
     </p>
 <p>
 Deweloperzy Tora nie sprawdzili tłumaczenia tej strony pod względem dokładności
  i poprawności. Tłumaczenie może być przestarzałe lub niepoprawne. Oficjalna strona Tora jest
  po angielsku, pod adresem <a href="https://www.torproject.org/">https://www.torproject.org/</a>.
 </p>
     <p>
     <i><a href="../contact.html.pl" class="smalllink">Webmaster</a></i> -
      Ostatnio zmodyfikowane: Fri Nov 13 13:41:59 2009
      -
      Ostatnio wygenerowane: Sat Jan 2 11:06:46 2010
     </p>
  </div>
</body>
</html>
