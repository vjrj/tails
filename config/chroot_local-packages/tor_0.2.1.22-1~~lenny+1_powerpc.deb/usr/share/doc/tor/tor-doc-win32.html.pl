<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/1998/REC-html40-19980424/loose.dtd">
<html>
<head>
  <title>Przekierowanie</title>
  <meta name="Author" content="Roger Dingledine">
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" type="text/css" href="../stylesheet-ltr.css">
  <link rel="shortcut icon" type="image/x-icon" href="../favicon.ico">
  <meta http-equiv="refresh" content="0;url=../docs/tor-doc-windows">
</head>
<body>
<div class="center">
<table class="banner" border="0" cellpadding="0" cellspacing="0" summary="">
    <tr>
        <td class="banner-left"><a href="https://www.torproject.org/"><img src="../images/top-left.png" alt="Click to go to home page" width="193" height="79"></a></td>
        <td class="banner-middle">
	<a href="../index.html.pl">Strona główna</a>
<a href="../overview.html.pl">Wprowadzenie</a>
<a href="../easy-download.html.pl">Pobieranie plików</a>
<a href="../documentation.html.pl">Dokumentacja</a>
<a href="../volunteer.html.pl">Wolontariusze</a>
<a href="../people.html.pl">Ludzie</a>
<a href="https://blog.torproject.org/">Blog</a>
<a href="../donate.html.pl">Dotacje</a>
        </td>
        <td class="banner-right">
	<a href="tor-doc-win32.html.de"><acronym title="Deutsch"><img src="../images/de.png" alt="Deutsch" width="24" height="16"></acronym></a> <a href="tor-doc-win32.html.en"><acronym title="English"><img src="../images/en.png" alt="English" width="24" height="16"></acronym></a> <a href="tor-doc-win32.html.es"><acronym title="espa&ntilde;ol"><img src="../images/es.png" alt="espa&ntilde;ol" width="24" height="16"></acronym></a> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <a href="tor-doc-win32.html.fr"><acronym title="fran&ccedil;ais"><img src="../images/fr.png" alt="fran&ccedil;ais" width="24" height="16"></acronym></a> <a href="tor-doc-win32.html.it"><acronym title="Italiano"><img src="../images/it.png" alt="Italiano" width="24" height="16"></acronym></a> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <acronym title="polski"><img src="../images/pl.png" alt="polski" width="24" height="16"></acronym> <a href="tor-doc-win32.html.pt"><acronym title="Portugu&ecirc;s"><img src="../images/pt.png" alt="Portugu&ecirc;s" width="24" height="16"></acronym></a> <a href="tor-doc-win32.html.ru"><acronym title="&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081;&nbsp;(Russkij)"><img src="../images/ru.png" alt="&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081;&nbsp;(Russkij)" width="24" height="16"></acronym></a> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <img src="../images/green-flagspace.png" alt="" width="24" height="16">
        </td>
    </tr>
</table>
Redirecting to <a href="../docs/tor-doc-windows">../docs/tor-doc-windows</a>.
<hr>
</div>
  <div class="bottom" id="bottom">
     <p>"Tor" i "Onion Logo" (logo cebuli) są <a href="../trademark-faq.html.pl">zarejestrowanymi znakami handlowymi</a> The Tor Project, Inc.<br>
	Zawartość tej strony jest pod licencją
	<a href="http://creativecommons.org/licenses/by/3.0/us/">Creative Commons Attribution
	3.0 United States License</a>, chyba że napisano inaczej.
	</p>
     <p>
       Ta strona jest także dostępna w następujących językach:
       <a href="tor-doc-win32.html.de">Deutsch</a>, <a href="tor-doc-win32.html.en">English</a>, <a href="tor-doc-win32.html.es">espa&ntilde;ol</a>, <a href="tor-doc-win32.html.fr">fran&ccedil;ais</a>, <a href="tor-doc-win32.html.it">Italiano</a>, <a href="tor-doc-win32.html.pt">Portugu&ecirc;s</a>, <a href="tor-doc-win32.html.ru">&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081;&nbsp;(Russkij)</a>.<br>
       Jak ustawić <a href="http://www.debian.org/intro/cn.pl.html#howtoset">domyślny język dokumentu</a>.
     </p>
 <p>
 Deweloperzy Tora nie sprawdzili tłumaczenia tej strony pod względem dokładności
  i poprawności. Tłumaczenie może być przestarzałe lub niepoprawne. Oficjalna strona Tora jest
  po angielsku, pod adresem <a href="https://www.torproject.org/">https://www.torproject.org/</a>.
 </p>
     <p>
     <i><a href="../contact.html.pl" class="smalllink">Webmaster</a></i> -
      Ostatnio zmodyfikowane: Tue Jul 8 04:54:06 2008
      -
      Ostatnio wygenerowane: Sat Jan 2 11:06:47 2010
     </p>
  </div>
</body>
</html>
