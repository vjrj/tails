<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/1998/REC-html40-19980424/loose.dtd">
<html>
<head>
  <title>Tor: Instrukcja konfiguracji przekaźnika sieci</title>
  <meta name="Author" content="Roger Dingledine">
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" type="text/css" href="../stylesheet-ltr.css">
  <link rel="shortcut icon" type="image/x-icon" href="../favicon.ico">
</head>
<body>
<div class="center">
<table class="banner" border="0" cellpadding="0" cellspacing="0" summary="">
    <tr>
        <td class="banner-left"><a href="https://www.torproject.org/"><img src="../images/top-left.png" alt="Click to go to home page" width="193" height="79"></a></td>
        <td class="banner-middle">
	<a href="../index.html.pl">Strona główna</a>
<a href="../overview.html.pl">Wprowadzenie</a>
<a href="../easy-download.html.pl">Pobieranie plików</a>
<a href="../documentation.html.pl">Dokumentacja</a>
<a href="../volunteer.html.pl">Wolontariusze</a>
<a href="../people.html.pl">Ludzie</a>
<a href="https://blog.torproject.org/">Blog</a>
<a href="../donate.html.pl">Dotacje</a>
        </td>
        <td class="banner-right">
	<a href="tor-doc-relay.html.de"><acronym title="Deutsch"><img src="../images/de.png" alt="Deutsch" width="24" height="16"></acronym></a> <a href="tor-doc-relay.html.en"><acronym title="English"><img src="../images/en.png" alt="English" width="24" height="16"></acronym></a> <a href="tor-doc-relay.html.es"><acronym title="espa&ntilde;ol"><img src="../images/es.png" alt="espa&ntilde;ol" width="24" height="16"></acronym></a> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <a href="tor-doc-relay.html.fr"><acronym title="fran&ccedil;ais"><img src="../images/fr.png" alt="fran&ccedil;ais" width="24" height="16"></acronym></a> <a href="tor-doc-relay.html.it"><acronym title="Italiano"><img src="../images/it.png" alt="Italiano" width="24" height="16"></acronym></a> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <a href="tor-doc-relay.html.ko"><acronym title="&#54620;&#44397;&#50612;&nbsp;(Hangul)"><img src="../images/ko.png" alt="&#54620;&#44397;&#50612;&nbsp;(Hangul)" width="24" height="16"></acronym></a> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <acronym title="polski"><img src="../images/pl.png" alt="polski" width="24" height="16"></acronym> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <a href="tor-doc-relay.html.ru"><acronym title="&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081;&nbsp;(Russkij)"><img src="../images/ru.png" alt="&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081;&nbsp;(Russkij)" width="24" height="16"></acronym></a> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <img src="../images/green-flagspace.png" alt="" width="24" height="16"> <a href="tor-doc-relay.html.zh-cn"><acronym title="&#20013;&#25991;(&#31616;) (Simplified Chinese)"><img src="../images/zh-cn.png" alt="&#20013;&#25991;(&#31616;) (Simplified Chinese)" width="24" height="16"></acronym></a>
        </td>
    </tr>
</table>
<div class="center">
<div class="main-column">
<h1>Konfiguracja przekaźnika Tora</h1>
<br>
<!-- BEGIN SIDEBAR -->
<div class="sidebar-left">
<h3>Kroki konfiguracji</h3>
<ol>
<li><a href="../docs/tor-doc-relay.html.pl#install">Pobieranie i instalacja</a></li>
<li><a href="../docs/tor-doc-relay.html.pl#setup">Konfiguracja</a></li>
<li><a href="../docs/tor-doc-relay.html.pl#check">Sprawdzenie i Potwierdzenie</a></li>
<li><a href="../docs/tor-doc-relay.html.pl#after">Ostatnie kroki</a></li>
</ol>
</div>
<!-- END SIDEBAR -->
<hr>
<p>Sieć Tora polega na ochotnikach oddających część swojego łącza. Im więcej
 ludzi uruchomi przekaźnik, tym szybsza będzie sieć Tora. Jeśli masz co najmniej
 20 kilobajtów/s w obie strony, pomóż Torowi, konfigurując swojego klienta tak,
 by był także przekaźnikiem sieci. Mamy wiele cech, które czynią przekaźniki Tora łatwymi i
 wygodnymi, łącznie z <a href="../faq.html.pl#RelayFlexible">ograniczeniem przepustowości,
 politykami wyjścia, byś mógł zmniejszyć ryzyko skarg, oraz obsługą dynamicznych adresów IP</a>.</p>
<p>Możesz uruchomić przekaźnik sieci Tora na <a
 href="https://wiki.torproject.org/noreply/TheOnionRouter/TorFAQ#RelayOS">prawie każdym</a>
 systemie operacyjnym. Przekaźniki Tora działają najlepiej na systemach Linux,
 OS X Tiger lub późniejszym, FreeBSD 5.x+, NetBSD 5.x+ oraz Windows Server 2003 lub późniejszym.
</p>
<hr>
<a id="zero"></a>
<a id="install"></a>
<h2><a class="anchor" href="#install">Krok 1: Pobranie i instalacja Tora</a></h2>
<br>
<p>Zanim zaczniesz, upewnij się, że Tor jest uruchomiony i działa.
</p>
<p>Odwiedź naszą <a href="../easy-download.html.pl">stronę pobierania</a> i zainstaluj
"Paczkę Instalacyjną" dla swojego systemu.
</p>
<p>Jeśli uznasz to za wygodne, możesz najpierw poużywać Tora jako klienta przez jakiś czas, by
 upewnić się, czy rzeczywiście działa.</p>
<hr>
<a id="setup"></a>
<h2><a class="anchor" href="#setup">Krok 2: Ustawienie Tora jako przekaźnika sieci</a></h2>
<br>
<ol>
<li> Sprawdź, czy twój zegar i strefa czasowa są dobrze ustawione. Jeśli jest to możliwe,
 zsynchronizuj swój zegar z publicznymi <a href="http://en.wikipedia.org/wiki/Network_Time_Protocol"
>serwerami czasu</a>.
</li>
<li><strong>Konfiguracja Tora z Interfejsem Graficznym Vidalia</strong>:
<ol>
 <li>
   <dt>Kliknij prawym klawiszem na ikonkę Vidalii w zasobniku systemowym. Wybierz
    <tt>Control Panel</tt> (Panel sterowania).</dt></li>
    <dd><img src="../img/screenshot-win32-vidalia.png" alt="" width="132" height="252"></dd>
 <li>Klinkij <tt>Setup Relaying</tt> (Uruchomienie przekazywania).</li>
 <li>
   <dt>Wybierz <tt>Relay Traffic for the Tor network</tt> (Przekazuj ruch dla sieci Tor),
       jeśli chcesz być publicznym przekaźnikiem (zalecane), lub wybierz <tt>Help censored users
       reach the Tor network</tt> (Pomóż cenzorowanym użytkownikom dostać się do sieci Tora),
       jeśli chcesz być <a href="../faq.html.pl#RelayOrBridge">mostkiem</a> dla użytkowników w
       krajach cenzurujących swój Internet.</dt>
       <dd><img src="../img/screenshot-win32-configure-relay-1.png" alt="" width="624" height="558"></dd>
 </li>
 <li>Wprowadź nazwę dla swojego przekaźnika i wprowadź informacje kontaktowe, w razie
   gdybyśmy musieli skontaktować się z Tobą w przypadku problemów.</li>
 <li>Zostaw <tt>Attempt to automatically configure port forwarding</tt> (Spróbuj automatycznie
  skonfigurować przekazywanie portów) włączone. Wciśnij przycisk <tt>Test</tt>, by sprawdzić, czy to
  działa. Jeśli tak, to wspaniale. Jeśli nie, spójrz na punkt numer 3 poniżej.</li>
 <li><dt>Wybierz kartę <tt>Bandwidth Limits</tt> (Ograniczenia łącza).
  Określ, ile z przepustowości łącza chcesz dać uzytkownikom Tora, takim jak Ty.</dt>
  <dd><img src="../img/screenshot-win32-configure-relay-2.png" alt="" width="622" height="562"></dd>
  </li>
 <li><dt>Wybierz kartę <tt>Exit Policies</tt> (Polityki wyjścia). Jeśli chcesz, by inni mogli
  używać Twojego przekaźnika dla tych usług, nie zmieniaj niczego. Wyłącz te usługi,
  co do których nie chcesz, by były osiągalne przez ludzi z <a href="../faq.html.pl#ExitPolicies">Twojego przekaźnika</a>. Jeśli chcesz być przekaźnikiem
  nie-wyjściowym, wyłącz wszystkie usługi.</dt></li>
  <dd><img src="../img/screenshot-win32-configure-relay-3.png" alt="" width="624" height="560"></dd>
 <li>Kliknij przycisk <tt>Ok</tt>. Spójrz na krok 3 poniżej w celu potwierdzenia, że
  przekaźnik działa prawidłowo.</li>
</ol>
<br>
<strong>Manual Configuration</strong>:
<ul>
 <li>
 Wyedytuj dolną część <a
 href="https://wiki.torproject.org/noreply/TheOnionRouter/TorFAQ#torrc">swojego pliku torrc</a>.)
 Jeśli chcesz być publicznym przekaźnikiem (zalecane),
 upewnij się, że podałeś ORPort i <a href="../faq.html.pl#ExitPolicies">sprawdź ExitPolicy</a>,
 jeśli chcesz być publicznym przekaźnikiem (zalecane), lub po prostu dodaj
 <a href="../bridges.html.pl#RunningABridge">te linie</a>; w innym przypadku, jeśli chcesz być
 <a href="../faq.html.pl#RelayOrBridge">mostkiem</a> dla użytkowników w krajach cenzurujących
 swój Internet, skorzystaj z <a href="../bridges.html.pl#RunningABridge">tych linii</a>.
 </li>
</ul></li>
<li>
 Jeśli używasz zapory ogniowej, otwórz w niej przejście, by połączenia
 przychodzące mogły dostać sie do skonfigurowanych portów (ORPort, plus
 DirPort, jeśli go włączyłeś). Jeśli masz firewall sprzętowy (Linksys, modem kablowy, itd),
 może spodobać Ci się <a href="http://portforward.com/">portforward.com</a>. Upewnij się też,
 że dozwolone są też wszystkie połączenia <em>wychodzące</em>, aby twój przekaźnik mógł dotrzeć
 do innych przekaźników Tora.
</li>
<li>
 Uruchom ponownie swój przekaźnik. Jeśli <a
 href="https://wiki.torproject.org/noreply/TheOnionRouter/TorFAQ#Logs">wypisze jakieś ostrzeżenia</a>,
 zajmij się nimi.
</li>
<li>
 Zapisz się na listę mailingową <a
 href="http://archives.seul.org/or/announce/">or-announce</a>.
 Ma ona mały ruch, dzięki niej będziesz informowany o nowych stabilnych wydaniach.
 Możesz także zapisać się na <a
 href="../documentation.html.pl#MailingLists">listy Tora o większym ruchu</a>.
</li>
</ol>
<hr>
<a id="check"></a>
<h2><a class="anchor" href="#check">Krok 3: Sprawdzenie, czy wszystko działa</a></h2>
<br>
<p>Jak tylko twój przekaźnik zdoła połączyć się z siecią, spróbuje określić,
 czy skonfigurowane porty są dostępne z zewnątrz. Ten krok jest zazwyczaj szybki, ale
 może potrwać do 20 minut. Szukaj
 <a href="https://wiki.torproject.org/noreply/TheOnionRouter/TorFAQ#Logs">wpisów
 do logów</a> w postaci
 <tt>Self-testing indicates your ORPort is reachable from the outside. Excellent.</tt>
 Jeśli nie widzisz tej wiadomości, to znaczy, że twój przekaźnik nie jest osiągalny z
 zewnątrz &mdash; powinieneś ponownie sprawdzić ustawienia zapory ogniowej, zobaczyć,
 czy sprawdza ten IP i port, który powinien sprawdzać etc.
</p>
<p>Gdy Tor stwierdzi, że jest osiągalny z zewnątrz, wyśle "deskryptor serwera" do
 serwerów katalogowych, by dać znać klientom, jakiego używasz
 adresu, portów, kluczy etc. Możesz <a
 href="http://moria.seul.org:9032/tor/status/authority">ręcznie otworzyć jedną ze stron
 zawierających status sieci</a> i poszukać w nim nazwy, którą skonfigurowałeś, by upewnić się, że
 tam jest. Możliwe, że będziesz musiał poczekać parę sekund, by utworzony
 został świeży katalog serwerów.</p>
<hr>
<a id="after"></a>
<h2><a class="anchor" href="#after">Krok 4: Gdy już wszystko działa</a></h2>
<br>
<p>
Polecamy też następujące kroki:
</p>
<p>
6. Przeczytaj
 <a href="https://wiki.torproject.org/noreply/TheOnionRouter/OperationalSecurity">o zabezpieczaniu
 działania</a>, by dowiedzieć sie, jak możesz podnieść bezpieczeństwo swojego przekaźnika.
</p>
<p>
7. Jeśli chcesz prowadzić więcej niż jeden przekaźnik, to wspaniale, ale prosimy o ustawienie <a
href="https://wiki.torproject.org/noreply/TheOnionRouter/TorFAQ#MultipleRelays">opcji
MyFamily</a> w plikach konfiguracyjnych wszystkich Twoich przekaźników.
</p>
<p>
8. Pomyśl o ograniczaniu przepustowości łącza. Użytkownicy sieci kablowych,
 DSL oraz inni z asymetrycznym łączem (np. większy download niż upload) powinni
 ograniczyć przepustowość Tora do tej mniejszej wartości, by uniknąć zatorów. Przeczytaj <a
 href="https://wiki.torproject.org/noreply/TheOnionRouter/TorFAQ#LimitBandwidth">wpis do FAQ
 na temat ograniczania przepustowości</a>.
</p>
<p>
9. Zrób kopię zapasową prywatnego klucza swojego przekaźnika (przechowywanego w
 "keys/secret_id_key" w katalogu DataDirectory). To jest "tożsamość" twojego
 przekaźnika i musisz trzymać ją w bezpiecznym miejscu, by nikt nie mógł
 podsłuchać ruchu, który przechodzi przez twój przekaźnik. To jest najważniejszy plik
 do zachowania w przypadku, gdy musisz <a
 href="https://wiki.torproject.org/noreply/TheOnionRouter/TorFAQ#UpgradeRelay">przenieść
 lub odbudować swój przekaźnik Tora</a> jeśli coś pójdzie nie tak.
</p>
<p>
10. Jeśli kontrolujesz serwery nazw w swojej domenie, rozważ ustawienie
 swojej nazwy hosta w odwrotnym DNSie na 'anonymous-relay' lub 'proxy' lub 'tor-proxy', aby inni
 mogli szybciej zrozumieć co się dzieje, gdy zobaczą twój adres w swoich logach.
 Dodanie <a href="https://tor-svn.freehaven.net/svn/tor/trunk/contrib/tor-exit-notice.html"
>infomracji o punkcie wyjścia z Tora</a> na wirtualnym hoście dla tej nazwy może bardzo
 pomóc w razie skarg o nadużycia kierowanych do Ciebie lub Twojego ISP, jeśli prowadzisz
 serwer wyjściowy Tora.
</p>
<p>
11. Jeśli na twoim komputerze nie ma serwera WWW, rozważ zmianę portu ORPort na
 443, a portu katalogowego DirPort na 80. Wielu z użytkowników Tora jest za
 zaporami ogniowymi, które pozwalają tylko przeglądać sieć WWW, ta zmiana pozwoli
 takim użytkownikom połączyć się z twoim przekaźnikiem. Operatorzy przekaźników pod Win32
 mogą po prostu bezpośrednio zmienić swój ORPort i DirPort w pliku torrc i
 ponownie uruchomić Tora. Przekaźniki pod OS X i Unix nie mogą bezpośrednio
 podłączyć się do tych portów (gdyż nie są uruchamiane jako root), więc dla nich
 trzeba uruchomić jakieś <a
 href="https://wiki.torproject.org/noreply/TheOnionRouter/TorFAQ#ServerForFirewalledClients">przekierowanie
 portów</a>, by połączenia mogły do nich dotrzeć. Jeśli już
 używasz portów 80 i 443, ale i tak chcesz pomóc, to innymi użytecznymi portami są
 22, 110 i 143.
</p>
<p>
12. Jeśli twój przekaźnik sieci Tora ma też inne usługi na tym samym adresie IP
 &mdash; jak na przykład publiczny serwer WWW &mdash; upewnij się, że
 połączenia do tego serwera są dozwolone także z tego samego komputera.
 Musisz zezwolić na te połączenia, gdyż klienci Tora odkryją, że twój
 przekaźnik Tora jest <a
 href="https://wiki.torproject.org/noreply/TheOnionRouter/TorFAQ#ExitEavesdroppers">najbezpieczniejszą
 drogą do połączenia się z tym serwerem</a>, i zawsze zbudują obwód, który
 będzie kończył się na twoim przekaźniku. Jeśli nie chcesz zezwalać na takie połączenia,
 musisz jawnie wykluczyć je w swojej polityce wyjścia.
</p>
<p>
13. (Tylko Unix). Utwórz osobnego użytkownika, na którego prawach będzie uruchamiany
 przekaźnik. Jeśli zainstalowałeś paczkę OS X lub deb lub rpm, to wszystko już jest zrobione.
 W innym przypadku musisz zrobić to ręcznie. (Przekaźnik Tora nie musi być uruchamiany
 jako root, więc dobrze jest nie uruchamiać go jako root. Uruchamianie jako
 użytkownik 'tor' unika problemów z indent i innymi usługami, które sprawdzają
 nazwę użytkownika. Jeśli jesteś paranoikiem, możesz śmiało <a
 href="https://wiki.torproject.org/noreply/TheOnionRouter/TorInChroot">umieścić Tora w
 chrootowanym środowisku</a>.)
</p>
<p>
14. (Tylko Unix) Twój system operacyjny prawdopodobnie ogranicza liczbę
 otwartych deskryptorów plików dla każdego procesu do 1024 (lub nawet mniej). Jeśli planujesz
 uruchomienie szybkiego węzła wyjściowego, to ta ilość prawdopodobnie
 nie wystarczy. W systemie Linux powinieneś dodać linię w stylu "toruser hard nofile 8192"
 do swojego pliku /etc/security/limits.conf (toruser oznacza użytkownika, na
 którego prawach uruchomiony jest Tor), po czym ponownie uruchomić Tora, jeśli
 jest zainstalowany jako pakiet (lub wylogować się i zalogować ponownie, jeśli
 uruchamiasz go sam).
</p>
<p>
15. Jeśli zainstalowałeś Tora z jakiejś paczki lub instalatora, prawdopodobnie
 uruchamia to Tora automatycznie w czasie ładowania systemu. Ale jeśli instalowałeś
 ze źródeł, to mogą ci się przydać skrypty inicjalizacyjne contrib/tor.sh lub contrib/torctl.
</p>
<p>Gdy zmieniasz konfigurację Tora, pamiętaj sprawdzić, czy Twój przekaźnik dalej działa
 po tych zmianach. Ustaw w pliku torrc opcję "ContactInfo", byśmy mogli się z Tobą
 skontaktować, jeśli powinieneś zainstalować nowszą wersję lub coś działa nie tak.
 Jeśli masz jakieś problemy lub pytania, przeczytaj sekcję
 the <a href="../documentation.html.pl#Support">Uzyskiwanie pomocy</a> lub
 <a href="../contact.html.pl">skontaktuj się z nami</a> na liście tor-ops. Dziękujemy,
 że pomagasz rosnąć sieci Tora!
</p>
<hr>
<p>Jeśli masz pomysły na ulepszenie tej strony, prosimy <a
href="../contact.html.pl">je do nas wysłać</a>. Dziękujemy!</p>
  </div><!-- #main -->
</div>
<hr>
</div>
  <div class="bottom" id="bottom">
     <p>"Tor" i "Onion Logo" (logo cebuli) są <a href="../trademark-faq.html.pl">zarejestrowanymi znakami handlowymi</a> The Tor Project, Inc.<br>
	Zawartość tej strony jest pod licencją
	<a href="http://creativecommons.org/licenses/by/3.0/us/">Creative Commons Attribution
	3.0 United States License</a>, chyba że napisano inaczej.
	</p>
     <p>
       Ta strona jest także dostępna w następujących językach:
       <a href="tor-doc-relay.html.de">Deutsch</a>, <a href="tor-doc-relay.html.en">English</a>, <a href="tor-doc-relay.html.es">espa&ntilde;ol</a>, <a href="tor-doc-relay.html.fr">fran&ccedil;ais</a>, <a href="tor-doc-relay.html.it">Italiano</a>, <a href="tor-doc-relay.html.ko">&#54620;&#44397;&#50612;&nbsp;(Hangul)</a>, <a href="tor-doc-relay.html.ru">&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081;&nbsp;(Russkij)</a>, <a href="tor-doc-relay.html.zh-cn">&#20013;&#25991;(&#31616;) (Simplified Chinese)</a>.<br>
       Jak ustawić <a href="http://www.debian.org/intro/cn.pl.html#howtoset">domyślny język dokumentu</a>.
     </p>
 <p>
 Deweloperzy Tora nie sprawdzili tłumaczenia tej strony pod względem dokładności
  i poprawności. Tłumaczenie może być przestarzałe lub niepoprawne. Oficjalna strona Tora jest
  po angielsku, pod adresem <a href="https://www.torproject.org/">https://www.torproject.org/</a>.
 </p>
     <p>
     <i><a href="../contact.html.pl" class="smalllink">Webmaster</a></i> -
      Ostatnio zmodyfikowane: Thu Dec 10 15:44:46 2009
      -
      Ostatnio wygenerowane: Sat Jan 2 11:06:46 2010
     </p>
  </div>
</body>
</html>
